# -*- coding: utf-8 -*-
# 第七轮梳理：①去🎲随机 ②标准粒子/变形粒子 ③随机度改名颗粒差异 ④变化速度滑杆 ⑤折叠按钮避让 ⑥去边界
import re, subprocess

def rep1(s, old, new, tag, fname):
    n=s.count(old)
    if n!=1: raise SystemExit('%s in %s: %d'%(tag,fname,n))
    return s.replace(old,new)

REPL=[
# 1 移除 🎲随机 按钮（功能与自主随机切换重复）
("    <button class=\"statebtn\" data-state=\"auto\">🎲 随机</button>\n",""),
# 2 主脚本暴露清除锁定接口（供开关恢复自主模式）
("  // 支持 ?st=状态 直达（分享/调试用，如 ?st=implode 直看害羞态）",
 "  window.__clearManualState=function(){ manualState=null; };\n  // 支持 ?st=状态 直达（分享/调试用，如 ?st=implode 直看害羞态）"),
# 3 开关恢复自主模式不再依赖 🎲 按钮
("""      var rb=document.querySelector('#stateRow .statebtn[data-state="auto"]');
      if(rb)rb.click();""",
 "      if(window.__clearManualState)window.__clearManualState();"),
# 4 皮肤改名：标准粒子 / 变形粒子
(">蜂群粒子</button>",">标准粒子</button>"),
(">胶质球</button>",">胶质球 · 变形</button>"),
("if(skinLbl)skinLbl.textContent='基础形态 · 蜂群粒子 / 胶质球';",
 "if(skinLbl)skinLbl.textContent='粒子形态 · 标准 / 变形';"),
# 5 随机度 → 颗粒差异（含义更直白）
("<label title=\"0=关闭随机，数值越大颗粒差异越大\">随机度</label>",
 "<label title=\"每颗粒子之间的尺寸/明暗差异。0=完全均匀，越大颗粒越参差\">颗粒差异</label>"),
# 6 变化速度滑杆（插在粒子大小之后）
("""    try{localStorage.setItem('ql_size',sa.value);}catch(e){}\n  });""",
 """    try{localStorage.setItem('ql_size',sa.value);}catch(e){}\n  });
  /* 变化速度：控制粒子运动与形变的快慢（0.2x~2x） */
  window.particleSpeed=parseFloat((function(){try{return localStorage.getItem('ql_speed');}catch(e){return null;}})()||'1');
  var spdRow=mk('div','row');
  spdRow.innerHTML='<label>变化速度</label><input type="range" id="speedAmt" min="0.2" max="2" step="0.05" value="'+window.particleSpeed+'"><output>'+window.particleSpeed+'x</output>';
  gPt.querySelector('.cbody').appendChild(spdRow);
  var spdIn=spdRow.querySelector('input');
  spdIn.addEventListener('input',function(){
    window.particleSpeed=parseFloat(spdIn.value);
    spdRow.querySelector('output').textContent=window.particleSpeed+'x';
    try{localStorage.setItem('ql_speed',spdIn.value);}catch(e){}
  });"""),
# 7 时钟乘以速度系数
("    var dt=1/60; t+=dt;",
 "    var dt=1/60; t+=dt*(window.particleSpeed===undefined?1:window.particleSpeed);"),
# 8 折叠后展开按钮下移，避让右上角状态徽章
("#btnUnfold{display:none;position:fixed;top:16px;right:16px;",
 "#btnUnfold{display:none;position:fixed;top:70px;right:16px;"),
# 9 边界线框球不再显示（安全约束仍内部生效）
("    boundMesh=new THREE.Mesh(boundGeo,boundMat); scene.add(boundMesh);",
 "    boundMesh=new THREE.Mesh(boundGeo,boundMat); scene.add(boundMesh);\n    boundMesh.visible=false; // 边界线框不显示，安全约束仍在内部生效"),
# 10 参数组移除边界半径
("""  var gParam=makeGroup('param','🎛 参数',false,[
    byId('sensitivity')?byId('sensitivity').closest('.row'):null,
    byId('boundR')?byId('boundR').closest('.row'):null]);""",
 """  var gParam=makeGroup('param','🎛 参数',false,[
    byId('sensitivity')?byId('sensitivity').closest('.row'):null]);
  var boundRow=byId('boundR')?byId('boundR').closest('.row'):null;
  if(boundRow&&boundRow.parentNode)boundRow.parentNode.removeChild(boundRow); // 移除边界半径调节（固定内部默认值）"""),
]

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    for i,(old,new) in enumerate(REPL):
        s=rep1(s,old,new,'R%d:%s'%(i,old[:24]),f)
    open(f,'w',encoding='utf-8',newline='').write(s)
    bad=0
    for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0: bad+=1; print(f,'block',k,'ERR',r.stderr[:200])
    print(f,'round8 OK, syntax','PASS' if bad==0 else 'FAIL')
import os; os.remove('_chk.js')
print('ROUND8 DONE')
