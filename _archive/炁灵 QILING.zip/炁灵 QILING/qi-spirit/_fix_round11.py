# -*- coding: utf-8 -*-
# 第十轮：萤火虫特效 —— 主粒子闪烁(着色器) + 少数飞行个体链式拖尾(占比可调)
import re, subprocess

REPL=[
# 1 贴图按钮：fiber 后加 萤火虫（占位，稍后正则插入）
# 2 PARTICLE_RENDER 注册（firefly 用 dust 贴图别名）
("    fiber:     {count:3000, size:0.10, opacity:0.45, additive:1},",
 """    fiber:     {count:3000, size:0.10, opacity:0.45, additive:1},
    firefly:   {count:9000, size:0.095, opacity:0.60, additive:1, blink:1},"""),
# 3 着色器 uniform：时间 + 闪烁开关
("        uCloudR:{value:0.6},",
 "        uCloudR:{value:0.6},\n        uTime:{value:0},\n        uBlink:{value:0},"),
# 4 片元着色器声明
("""        'uniform float uAdd;',
        'uniform float uRand;',
        'varying float vSeed;',""",
 """        'uniform float uAdd;',
        'uniform float uRand;',
        'uniform float uTime;',
        'uniform float uBlink;',
        'varying float vSeed;',"""),
# 5 萤火虫闪烁：随机频率/相位的正弦呼吸（忽明忽暗，永不同步）
("""        '  if(t.a<0.02) discard;',""",
 """        '  if(t.a<0.02) discard;',
        '  float blink=1.0;',
        '  if(uBlink>0.5){',
        '    float bf=0.5+0.5*sin(uTime*(0.5+1.7*fract(vSeed*7.31))+vTint*6.2832);',
        '    blink=0.10+0.90*bf*bf;',
        '  }',"""),
# 6 两条输出乘 blink
("'    gl_FragColor=vec4(col*t.r*t.a*uOpacity*vA*vEdge,1.0);',",
 "'    gl_FragColor=vec4(col*t.r*t.a*uOpacity*vA*vEdge*blink,1.0);',"),
("'    gl_FragColor=vec4(col*(0.55+0.45*t.r), pow(t.a,1.2)*uOpacity*vA*vEdge);',",
 "'    gl_FragColor=vec4(col*(0.55+0.45*t.r), pow(t.a,1.2)*uOpacity*vA*vEdge*blink);',"),
# 7 渲染循环：时间/闪烁 uniform + 拖尾子系统挂载
("          u.uCloudR.value=(mat._dR||0.6);",
 """          u.uCloudR.value=(mat._dR||0.6);
          u.uTime.value=t;
          u.uBlink.value=(_tex&&_tex.name==='firefly')?1:0;
          if(_tex&&_tex.name==='firefly'){
            if(!ffPts) initFirefly();
            if(!ffPts.visible){ ffPts.visible=true; ghPts.visible=true; }
            updateFirefly();
          } else if(ffPts&&(ffPts.visible||ghPts.visible)){ ffPts.visible=false; ghPts.visible=false; }"""),
# 8 dust 加载完成后派生 firefly 别名贴图（共用图像，独立名字）
("""        if(mat){ applyTextureToMaterial(mat, skin, stateName); }
      },undefined,function(err){ console.warn('粒子贴图加载失败:', key, err); });""",
 """        if(key==='dust'&&!PARTICLE_TEXTURES.firefly){
          var ft=tex.clone(); ft.name='firefly'; ft.needsUpdate=true;
          PARTICLE_TEXTURES.firefly=ft;
          var fb=document.querySelector('.particlebtn[data-particle="firefly"] .thumb');
          if(fb) fb.style.backgroundImage='url('+PARTICLE_IMG[key]+')';
        }
        if(mat){ applyTextureToMaterial(mat, skin, stateName); }
      },undefined,function(err){ console.warn('粒子贴图加载失败:', key, err); });"""),
# 9 萤火虫子系统（飞行个体 + 链式拖尾）
("  // 粒子效果按钮：点击立即切换",
 """  // ===== 萤火虫特效：飞行个体 + 链式拖尾（链上光点逐节缓动跟随，形成天然弧线光迹）=====
  var FF_MAX=2700, FF_G=6;
  var ffPts=null, ghPts=null, ffGeo=null, ghGeo=null, ffMat=null, ghMat=null;
  var ffPos=null, ffSeed=null, ghPos=null, ghTA=null;
  function initFirefly(){
    if(ffPts||typeof THREE==='undefined'||!scene) return;
    ffPos=new Float32Array(FF_MAX*3); ffSeed=new Float32Array(FF_MAX);
    ghPos=new Float32Array(FF_MAX*FF_G*3); ghTA=new Float32Array(FF_MAX*FF_G);
    function frc(x){ return x-Math.floor(x); }
    for(var i=0;i<FF_MAX;i++){
      var sd=Math.random(); ffSeed[i]=sd;
      var r=1.6*Math.cbrt(Math.random()), th=frc(sd*7.0)*6.2832, ph=Math.acos(2*frc(sd*13.7)-1);
      ffPos[i*3]=r*Math.sin(ph)*Math.cos(th); ffPos[i*3+1]=r*Math.cos(ph)*0.7; ffPos[i*3+2]=r*Math.sin(ph)*Math.sin(th);
      for(var j=0;j<FF_G;j++){ var k=(i*FF_G+j)*3; ghPos[k]=ffPos[i*3]; ghPos[k+1]=ffPos[i*3+1]; ghPos[k+2]=ffPos[i*3+2]; ghTA[i*FF_G+j]=FF_G>1?j/(FF_G-1):0; }
    }
    ffGeo=new THREE.BufferGeometry();
    ffGeo.setAttribute('position',new THREE.BufferAttribute(ffPos,3));
    ffGeo.setAttribute('aSeed',new THREE.BufferAttribute(ffSeed,1));
    ffMat=new THREE.ShaderMaterial({
      uniforms:{uTime:{value:0},uScale:{value:450},uSize:{value:0.14},uColor:{value:new THREE.Color(0xFFE9A8)},uOpacity:{value:0.9}},
      vertexShader:[
        'attribute float aSeed;',
        'varying float vS;',
        'uniform float uTime; uniform float uScale; uniform float uSize;',
        'void main(){',
        '  vS=aSeed;',
        '  vec4 mv=modelViewMatrix*vec4(position,1.0);',
        '  float tw=0.7+0.3*sin(uTime*(1.2+2.0*fract(aSeed*5.7))+aSeed*40.0);',
        '  gl_PointSize=uSize*(0.8+0.5*tw)*uScale/max(0.1,-mv.z);',
        '  gl_Position=projectionMatrix*mv;',
        '}'
      ].join('\\n'),
      fragmentShader:[
        'uniform vec3 uColor; uniform float uOpacity; uniform float uTime;',
        'varying float vS;',
        'void main(){',
        '  float d=length(gl_PointCoord-vec2(0.5)); if(d>0.5) discard;',
        '  float core=pow(smoothstep(0.5,0.0,d),1.8);',
        '  vec3 col=mix(vec3(1.0,0.95,0.55),uColor,0.35);',
        '  float f=0.55+0.45*sin(uTime*(1.5+2.0*fract(vS*5.7))+vS*40.0);',
        '  gl_FragColor=vec4(col*core*uOpacity*(0.35+0.65*f),1.0);',
        '}'
      ].join('\\n'),
      transparent:true, depthWrite:false, blending:THREE.AdditiveBlending });
    ffPts=new THREE.Points(ffGeo,ffMat); ffPts.visible=false; ffPts.frustumCulled=false; scene.add(ffPts);
    ghGeo=new THREE.BufferGeometry();
    ghGeo.setAttribute('position',new THREE.BufferAttribute(ghPos,3));
    ghGeo.setAttribute('aT',new THREE.BufferAttribute(ghTA,1));
    ghMat=new THREE.ShaderMaterial({
      uniforms:{uTime:{value:0},uScale:{value:450},uSize:{value:0.13},uColor:{value:new THREE.Color(0xFFE9A8)},uOpacity:{value:0.5}},
      vertexShader:[
        'attribute float aT; varying float vT;',
        'uniform float uScale; uniform float uSize;',
        'void main(){',
        '  vT=aT;',
        '  vec4 mv=modelViewMatrix*vec4(position,1.0);',
        '  gl_PointSize=uSize*(1.0-aT*0.75)*uScale/max(0.1,-mv.z);',
        '  gl_Position=projectionMatrix*mv;',
        '}'
      ].join('\\n'),
      fragmentShader:[
        'uniform vec3 uColor; uniform float uOpacity;',
        'varying float vT;',
        'void main(){',
        '  float d=length(gl_PointCoord-vec2(0.5)); if(d>0.5) discard;',
        '  float a=pow(1.0-vT,2.0)*smoothstep(0.5,0.0,d)*uOpacity*0.45;',
        '  vec3 col=mix(uColor,vec3(0.72,1.0,0.5),0.4);', // 拖尾偏黄绿，模拟发光衰减
        '  gl_FragColor=vec4(col*a,1.0);',
        '}'
      ].join('\\n'),
      transparent:true, depthWrite:false, blending:THREE.AdditiveBlending });
    ghPts=new THREE.Points(ghGeo,ghMat); ghPts.visible=false; ghPts.frustumCulled=false; scene.add(ghPts);
  }
  function updateFirefly(){
    var ratio=(window.trailRatio===undefined?0.12:window.trailRatio);
    var F=Math.floor(COUNT*ratio); if(F>FF_MAX)F=FF_MAX; if(F<4)F=4;
    ffGeo.setDrawRange(0,F); ghGeo.setDrawRange(0,F*FF_G);
    var scl=(renderer&&renderer.domElement?renderer.domElement.height:900)*0.5;
    ffMat.uniforms.uTime.value=t; ffMat.uniforms.uScale.value=scl;
    ghMat.uniforms.uTime.value=t; ghMat.uniforms.uScale.value=scl;
    for(var i=0;i<F;i++){
      var s1=ffSeed[i], s2=(s1*7.13)%1, s3=(s1*3.71)%1;
      var R=0.85+0.55*s2;
      var wx=Math.sin(t*(0.16+s1*0.30)+s1*47.0)*R+Math.sin(t*1.07+s3*9.0)*0.16;
      var wy=Math.sin(t*(0.13+s2*0.26)+s2*47.0)*0.62+Math.cos(t*0.83+s1*7.0)*0.14;
      var wz=Math.cos(t*(0.15+s3*0.28)+s3*47.0)*R;
      var ix=i*3;
      ffPos[ix]+=(wx-ffPos[ix])*0.022; ffPos[ix+1]+=(wy-ffPos[ix+1])*0.022; ffPos[ix+2]+=(wz-ffPos[ix+2])*0.022;
      var px=ffPos[ix], py=ffPos[ix+1], pz=ffPos[ix+2];
      for(var j=0;j<FF_G;j++){
        var k=(i*FF_G+j)*3;
        ghPos[k]+=(px-ghPos[k])*0.30; ghPos[k+1]+=(py-ghPos[k+1])*0.30; ghPos[k+2]+=(pz-ghPos[k+2])*0.30;
        px=ghPos[k]; py=ghPos[k+1]; pz=ghPos[k+2];
      }
    }
    ffGeo.attributes.position.needsUpdate=true;
    ghGeo.attributes.position.needsUpdate=true;
  }
  // 粒子效果按钮：点击立即切换"""),
]

# uiPro：拖尾占比滑杆（挂在粒子大小滑杆之后）
TRAIL_OLD="    try{localStorage.setItem('ql_speed',spdIn.value);}catch(e){}\n  });"
TRAIL_NEW="""    try{localStorage.setItem('ql_speed',spdIn.value);}catch(e){}\n  });
  /* 拖尾占比（萤火虫模式：带光迹飞行的个体比例，4%~30%） */
  window.trailRatio=parseFloat((function(){try{return localStorage.getItem('ql_trail');}catch(e){return null;}})()||'0.12');
  var trRow=mk('div','row');
  trRow.innerHTML='<label title=\\\"萤火虫模式下，带拖尾光迹飞行的个体占比\\\">拖尾占比</label><input type=\"range\" id=\"trailAmt\" min=\"0.04\" max=\"0.3\" step=\"0.01\" value=\"'+window.trailRatio+'\"><output>'+Math.round(window.trailRatio*100)+'%</output>';
  gPt.querySelector('.cbody').appendChild(trRow);
  var trIn=trRow.querySelector('input');
  trIn.addEventListener('input',function(){
    window.trailRatio=parseFloat(trIn.value);
    trRow.querySelector('output').textContent=Math.round(window.trailRatio*100)+'%';
    try{localStorage.setItem('ql_trail',trIn.value);}catch(e){}
  });"""

FF_BTN='<button class="particlebtn" data-particle="firefly"><span class="thumb" style="background-image:radial-gradient(circle at 50% 45%,#FFF3B0 0%,#C8E86A 45%,rgba(20,40,20,0) 78%);"></span><span class="lbl">萤火虫</span></button>'
BTN_RE=re.compile(r'(<button class="particlebtn" data-particle="fiber"[^>]*>[\s\S]*?</button>)')

def rep1(s, old, new, tag, fname):
    n=s.count(old)
    if n!=1: raise SystemExit('%s in %s: %d'%(tag,fname,n))
    return s.replace(old,new)

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    for i,(old,new) in enumerate(REPL):
        if i==0: continue
        s=rep1(s,old,new,'R%d'%i,f)
    s,n=BTN_RE.subn(lambda m: m.group(1)+'\n    '+FF_BTN, s, count=1)
    if n!=1: raise SystemExit('btn in '+f)
    s=rep1(s,TRAIL_OLD,TRAIL_NEW,'trail-slider',f)
    open(f,'w',encoding='utf-8',newline='').write(s)
    bad=0
    for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0: bad+=1; print(f,k,r.stderr[:200])
    print(f,'firefly OK, syntax','PASS' if bad==0 else 'FAIL')
import os; os.remove('_chk.js')
print('ROUND11 DONE')
