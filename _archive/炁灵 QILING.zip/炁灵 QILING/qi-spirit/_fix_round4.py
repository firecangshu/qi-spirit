# -*- coding: utf-8 -*-
# 第四轮：① cellplate 更小更细密 ② 「粒子大小」全局控制条
import re

SIZE_LOOP_OLD="          u.uSize.value=(_cfg?_cfg.size:(skin==='swarm'?0.075:0.16))*(1+audioScale*0.25);"
SIZE_LOOP_NEW="          u.uSize.value=(_cfg?_cfg.size:(skin==='swarm'?0.075:0.16))*(window.particleSize===undefined?1:window.particleSize)*(1+audioScale*0.25);"

SIZE_UI_ANCHOR="    try{localStorage.setItem('ql_rand',ra.value);}catch(e){}\n  });"
SIZE_UI_NEW="""    try{localStorage.setItem('ql_rand',ra.value);}catch(e){}\n  });
  /* 粒子大小全局缩放（40%~200%，对所有素材生效） */
  window.particleSize=parseFloat((function(){try{return localStorage.getItem('ql_size');}catch(e){return null;}})()||'1');
  var sizeRow=mk('div','row');
  sizeRow.innerHTML='<label>粒子大小</label><input type="range" id="sizeAmt" min="0.4" max="2" step="0.05" value="'+window.particleSize+'"><output>'+Math.round(window.particleSize*100)+'%</output>';
  gPt.querySelector('.cbody').appendChild(sizeRow);
  var sa=sizeRow.querySelector('input');
  sa.addEventListener('input',function(){
    window.particleSize=parseFloat(sa.value);
    sizeRow.querySelector('output').textContent=Math.round(window.particleSize*100)+'%';
    try{localStorage.setItem('ql_size',sa.value);}catch(e){}
  });"""

CP_OLD="    cellplate: {count:300,  size:0.50, opacity:0.92, additive:0},"
CP_NEW="    cellplate: {count:480,  size:0.30, opacity:0.92, additive:0},"

def rep1(s, old, new, tag, fname):
    n=s.count(old)
    if n!=1: raise SystemExit('%s in %s: %d occurrences'%(tag,fname,n))
    return s.replace(old,new)

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    s=rep1(s,SIZE_LOOP_OLD,SIZE_LOOP_NEW,'size-uniform',f)
    s=rep1(s,SIZE_UI_ANCHOR,SIZE_UI_NEW,'size-ui',f)
    s=rep1(s,CP_OLD,CP_NEW,'cellplate',f)
    open(f,'w',encoding='utf-8',newline='').write(s)
    print(f,'round4 OK')
print('ROUND4 DONE')
