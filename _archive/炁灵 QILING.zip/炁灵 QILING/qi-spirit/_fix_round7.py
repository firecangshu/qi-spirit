# -*- coding: utf-8 -*-
# 第六轮：① 蜂群/胶质球并入粒子效果 ② 新增「情绪颜色」实时调色组 ③ 分组顺序重排
import re, subprocess

# 1) 主脚本暴露颜色 API（改色立即生效 + 存档）
API_OLD="  function stateColorOf(m){ if(qProfile&&qProfile[m]&&qProfile[m].color) return hexToRgb(qProfile[m].color); if(EXT_COLOR&&EXT_COLOR[m]) return hexToRgb(qProfile[m].color); return {r:143,g:214,b:209}; }"
# 注意：实际代码第二分支是 EXT_COLOR[m]，先探测
API_OLD_REAL="  function stateColorOf(m){ if(qProfile&&qProfile[m]&&qProfile[m].color) return hexToRgb(qProfile[m].color); if(EXT_COLOR&&EXT_COLOR[m]) return hexToRgb(EXT_COLOR[m]); return {r:143,g:214,b:209}; }"
API_NEW=API_OLD_REAL+"""
  // 供 UI 实时调色：list 返回 11 情绪当前颜色，set 修改并立即生效+持久化
  window.QilingColor={
    list:function(){ var out=[]; MOTIONS.forEach(function(m){ if(qProfile&&qProfile[m]) out.push({m:m,emo:qProfile[m].emo,color:qProfile[m].color}); }); return out; },
    set:function(m,c){ if(qProfile&&qProfile[m]){ qProfile[m].color=c; try{saveProfile();}catch(e){} tgtColor=hexToRgb(c); } }
  };"""

# 2) 合并 皮肤 + 粒子效果，改小标题
GP_OLD="""  var gSkin=makeGroup('skin','🎨 视觉皮肤',false,[labelByPrefix('视觉皮肤'),byId('skinRow')]);
  var gPt=makeGroup('pt','✨ 粒子效果',true,[labelByPrefix('粒子效果'),byId('particleRow')]);"""
GP_NEW="""  var skinLbl=labelByPrefix('视觉皮肤'); if(skinLbl)skinLbl.textContent='基础形态 · 蜂群粒子 / 胶质球';
  var ptLbl=labelByPrefix('粒子效果'); if(ptLbl)ptLbl.textContent='贴图素材 · 点击切换';
  var gPt=makeGroup('pt','✨ 粒子效果',true,[skinLbl,byId('skinRow'),ptLbl,byId('particleRow')]);"""

# 3) 参数组之后追加颜色组
GP_PARAM_OLD="""  var gParam=makeGroup('param','🎛 参数',false,[
    byId('sensitivity')?byId('sensitivity').closest('.row'):null,
    byId('boundR')?byId('boundR').closest('.row'):null]);"""
GP_PARAM_NEW=GP_PARAM_NEW="""  var gParam=makeGroup('param','🎛 参数',false,[
    byId('sensitivity')?byId('sensitivity').closest('.row'):null,
    byId('boundR')?byId('boundR').closest('.row'):null]);
  /* 情绪颜色：11 种情绪的实时调色 */
  var colorBox=mk('div');
  colorBox.style.cssText='display:grid;grid-template-columns:1fr 1fr;gap:5px 10px;max-height:36vh;overflow-y:auto;padding-right:2px;';
  var colorHint=mk('div'); colorHint.style.cssText='grid-column:1/3;font-size:10px;color:#6FA8A3;line-height:1.5;';
  colorHint.textContent='改色立即生效并保存到本机；扩展形态颜色跟随当前情绪。';
  colorBox.appendChild(colorHint);
  if(window.QilingColor){
    window.QilingColor.list().forEach(function(it){
      var cell=mk('label');
      cell.style.cssText='display:flex;align-items:center;gap:6px;font-size:10.5px;color:#8FB5B1;cursor:pointer;white-space:nowrap;';
      var inp=mk('input');
      inp.type='color'; inp.value=it.color;
      inp.style.cssText='width:24px;height:18px;border:none;background:transparent;padding:0;cursor:pointer;flex:none;';
      inp.addEventListener('input',function(){ window.QilingColor.set(it.m,inp.value); });
      cell.appendChild(inp); cell.appendChild(document.createTextNode(it.emo));
      colorBox.appendChild(cell);
    });
  }
  var gColor=makeGroup('color','🎨 情绪颜色',false,[colorBox]);"""

# 4) 顺序重排：情绪 → 形态 → 粒子 → 颜色 → 音频 → 参数
ORDER_OLD="[gAudio,gEmo,gExt,gSkin,gPt,gParam].forEach(function(g){panel.appendChild(g);});"
ORDER_NEW="[gEmo,gExt,gPt,gColor,gAudio,gParam].forEach(function(g){panel.appendChild(g);});"

def rep1(s, old, new, tag, fname):
    n=s.count(old)
    if n!=1: raise SystemExit('%s in %s: %d'%(tag,fname,n))
    return s.replace(old,new)

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    if s.count(API_OLD_REAL)!=1:
        raise SystemExit('stateColorOf anchor missing in '+f+' — check actual text')
    s=rep1(s,API_OLD_REAL,API_NEW,'color-api',f)
    s=rep1(s,GP_OLD,GP_NEW,'merge-skin',f)
    s=rep1(s,GP_PARAM_OLD,GP_PARAM_NEW,'color-group',f)
    s=rep1(s,ORDER_OLD,ORDER_NEW,'order',f)
    open(f,'w',encoding='utf-8',newline='').write(s)
    bad=0
    for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0: bad+=1; print(f,'block',k,'ERR',r.stderr[:200])
    print(f,'round7 OK, syntax', 'OK' if bad==0 else 'FAIL')
import os
os.remove('_chk.js')
print('ROUND7 DONE')
