# -*- coding: utf-8 -*-
# 第八轮：①滑杆数值防遮挡 ②渲染分辨率拉满+FPS自适应 ③新增三首悠扬曲目
import re, subprocess

REPL=[
# 1 滑杆自适应收缩，数值不再被卡片边缘裁切
("'.cbody .row label{white-space:nowrap;font-size:10.5px !important;}',",
 "'.cbody .row label{white-space:nowrap;font-size:10.5px !important;}',\n'.cbody .row input[type=range]{flex:1 1 auto;width:auto;min-width:0;}',\n'.cbody .row output{flex:none;margin-left:8px;}',"),
# 2 分辨率上限 2→3（跟随设备 DPR 拉满）
("    renderer.setSize(W,H); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));",
 "    renderer.setSize(W,H); renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,3)); // 分辨率拉满，配合 FPS 自适应降档保流畅"),
# 3 FPS 自适应：持续低于 40fps 自动逐级降 pixelRatio（最低 1）
("    var dt=1/60; t+=dt*(window.particleSpeed===undefined?1:window.particleSpeed);",
 """    var dt=1/60; t+=dt*(window.particleSpeed===undefined?1:window.particleSpeed);
    if(useWebGL&&renderer){
      window.__fpsN=(window.__fpsN||0)+1;
      var _now=performance.now();
      if(window.__fpsLast){ window.__fpsAcc=(window.__fpsAcc||0)+(_now-window.__fpsLast); }
      window.__fpsLast=_now;
      if(window.__fpsN>=90){
        var _avg=window.__fpsAcc/window.__fpsN;
        if(_avg>25&&renderer.getPixelRatio()>1){
          var _pr=Math.max(1,renderer.getPixelRatio()-0.25);
          renderer.setPixelRatio(_pr); if(composer)composer.setPixelRatio(_pr);
        }
        window.__fpsN=0; window.__fpsAcc=0;
      }
    }"""),
# 4 三首悠扬曲目的音符序列（追加在小星星定义之后）
("""    60,60,67,67,69,69,67,65,65,64,64,62,62,60
  ];""",
 """    60,60,67,67,69,69,67,65,65,64,64,62,62,60
  ];
  // 卡农（帕赫贝尔，D大调，分解和弦流动）
  var CANON=[
    62,66,69,74,78,74,69,66, 57,61,64,69,73,69,64,61,
    59,62,66,71,74,71,66,62, 54,57,61,66,69,66,61,57,
    55,59,62,67,71,67,62,59, 62,66,69,74,78,74,69,66,
    55,59,62,67,71,67,62,59, 57,61,64,69,73,69,64,61
  ];
  // 天鹅湖（柴可夫斯基，B小调主题）
  var SWANLAKE=[
    78,0,71,73,74,76,74,73, 71,0,66,68,69,71,69,68,
    66,0,71,0,74,0,73,71, 73,0,0,0,74,0,0,0,
    78,0,71,73,74,76,74,73, 71,0,66,68,69,71,69,68,
    66,0,71,0,74,0,73,71, 71,0,0,0,0,0,0,0
  ];
  // 月光（贝多芬，A小调改编，三连音琶音）
  var MOONLIGHT=[
    52,57,60,64,60,57, 52,57,60,64,60,57,
    50,55,59,64,59,55, 50,55,59,64,59,55,
    48,55,60,64,60,55, 48,55,60,64,60,55,
    45,52,57,60,57,52, 45,52,57,60,57,52,
    52,57,60,64,69,76, 76,0,74,0,72,0,
    50,55,59,64,67,71, 71,0,72,0,71,0,
    48,55,60,64,69,76, 74,0,72,0,71,0,
    45,52,57,60,57,52, 40,0,0,0,0,0
  ];"""),
# 5 getSongSeq 注册
("""    if(name==='furelise') return FUR;
    if(name==='twinkle') return TWINKLE;""",
 """    if(name==='furelise') return FUR;
    if(name==='twinkle') return TWINKLE;
    if(name==='canon') return CANON;
    if(name==='swanlake') return SWANLAKE;
    if(name==='moonlight') return MOONLIGHT;"""),
# 6 徽章名称表
("    var names={ode:'欢乐颂',furelise:'致爱丽丝',twinkle:'小星星'};",
 "    var names={ode:'欢乐颂',furelise:'致爱丽丝',twinkle:'小星星',canon:'卡农',swanlake:'天鹅湖',moonlight:'月光'};"),
]

OPT_OLD_DEMO='      <option value="twinkle">⭐ 小星星变奏（莫扎特）</option>'
OPT_NEW='''      <option value="twinkle">⭐ 小星星变奏（莫扎特）</option>
      <option value="canon">🎵 卡农（帕赫贝尔）</option>
      <option value="swanlake">🦢 天鹅湖（柴可夫斯基）</option>
      <option value="moonlight">🌙 月光（贝多芬）</option>'''
OPT_RE=re.compile(r'(      <option value="twinkle"[^>]*>⭐ 小星星变奏（莫扎特）</option>)')

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    for i,(old,new) in enumerate(REPL):
        n=s.count(old)
        if n!=1: raise SystemExit('R%d in %s: %d'%(i,f,n))
        s=s.replace(old,new)
    s,n=OPT_RE.subn(lambda m: m.group(1)+'\n'+OPT_NEW.split('\n',1)[1], s, count=1)
    if n!=1: raise SystemExit('opt in '+f)
    open(f,'w',encoding='utf-8',newline='').write(s)
    bad=0
    for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0: bad+=1; print(f,k,r.stderr[:150])
    print(f,'round9 OK, syntax','PASS' if bad==0 else 'FAIL')
import os; os.remove('_chk.js')
print('ROUND9 DONE')
