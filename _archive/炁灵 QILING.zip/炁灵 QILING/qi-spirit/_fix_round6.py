# -*- coding: utf-8 -*-
# 移除与 UI Pro 冲突的 buildFold 重组块（保留 ?state=/automusic 参数），修复双 </script>
import re, subprocess

START='  // ===== 分组卡片折叠'
END='  update();\n})();'
for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    i=s.find(START)
    if i>=0:
        j=s.find(END,i)
        assert j>i, f
        s=s[:i]+s[j:]
        print(f,'buildFold removed')
    n=s.count('</script>\n</script>')
    if n:
        s=s.replace('</script>\n</script>','</script>')
        print(f,'fixed %d doubled /script'%n)
    open(f,'w',encoding='utf-8',newline='').write(s)
    # 语法自检
    bad=0
    for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0: bad+=1; print(f,'block',k,'ERR',r.stderr[:200])
    print(f,'syntax', 'OK' if bad==0 else 'FAIL')
import os
os.remove('_chk.js')
print('DONE')
