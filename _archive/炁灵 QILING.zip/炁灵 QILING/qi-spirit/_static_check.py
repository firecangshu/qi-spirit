# -*- coding: utf-8 -*-
# 静态深度检测：JS语法 / 重复ID / getElementById引用完整性 / 三文件diff / 控制字符
import re, subprocess, os, collections

FILES=['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']
issues=[]

for f in FILES:
    s=open(f,encoding='utf-8').read()
    print('==='+f+' ('+str(len(s)//1024)+'KB)')
    # 1 控制字符
    ctrl=[hex(ord(c)) for c in s if ord(c)<9 or (11<=ord(c)<=12) or (14<=ord(c)<=31)]
    if ctrl: issues.append((f,'控制字符',ctrl[:5]))
    # 2 JS 语法
    for i,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0:
            issues.append((f,'JS语法 block%d'%i,r.stderr[:150]))
    # 3 重复 ID
    ids=re.findall(r'id="([^"]+)"', s)
    dup=[k for k,v in collections.Counter(ids).items() if v>1]
    if dup: issues.append((f,'重复HTML id',dup))
    # 4 JS 里 getElementById / querySelector 引用的 id 是否存在
    html_part=re.sub(r'<script>.*?</script>','',s,flags=re.S)
    have=set(re.findall(r'id="([^"]+)"',html_part))
    # 动态创建的 id 白名单
    dynamic=set(re.findall(r"\.id\s*=\s*['\"]([\w-]+)['\"]", s))
    dynamic|=set(re.findall(r"\bid=\\?['\"]([\w-]+)\\?['\"]", s))  # innerHTML 字符串里的 id
    used=set(re.findall(r"getElementById\(['\"]([\w-]+)['\"]\)", s))
    used|=set(re.findall(r"querySelector(?:All)?\(['\"]#([\w-]+)", s))
    missing=[u for u in sorted(used) if u not in have and u not in dynamic]
    if missing: issues.append((f,'引用了不存在的id',missing))
    # 5 addEventListener('click') 数量统计（按键功能面）
    n_click=len(re.findall(r"addEventListener\('click'", s))
    print('  click handlers:',n_click,'| ids:',len(have),'| used:',len(used))

# 6 三文件一致性：核心段应相同
def seg(f,a,b):
    s=open(f,encoding='utf-8').read()
    i=s.index(a); j=s.index(b,i)
    return s[i:j]
core_marks=[('  // ================= 粒子贴图素材','  // 粒子效果按钮：点击立即切换'),
            ('  function initWebGL()','  function initCanvas2D()')]
base=open(FILES[0],encoding='utf-8').read()
for a,b in core_marks:
    ref=seg(FILES[0],a,b)
    for f in FILES[1:]:
        if seg(f,a,b)!=ref: issues.append((f,'核心段不一致',a[:30]))
# uiPro 一致性
def uipro(f):
    s=open(f,encoding='utf-8').read()
    i=s.find('uiProStyle'); 
    return s[i:i+20000] if i>=0 else 'MISSING'
for f in FILES[1:]:
    pass  # uiPro 含 location 相关，跳过严格比对，只查存在性
for f in FILES:
    s=open(f,encoding='utf-8').read()
    for key in ['autoRandBtn','QilingColor','setAutoRandom','ql_folded','randAmt','sizeAmt','PARTICLE_IMG','UnrealBloomPass']:
        if key not in s: issues.append((f,'缺少关键功能',key))

os.remove('_chk.js')
print()
if issues:
    print('发现问题:')
    for it in issues: print(' -',it)
else:
    print('静态检测全部通过 ✓')
