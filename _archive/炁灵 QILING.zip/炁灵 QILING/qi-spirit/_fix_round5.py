# -*- coding: utf-8 -*-
# 第五轮：自主随机切换开关（情绪自动巡游 可显式关闭）
import subprocess, re

MAIN_OLD="""      if(s==='auto'){ manualState=null; }
      else {"""
MAIN_NEW="""      if(s==='auto'){ manualState=null; if(window.setAutoRandom)window.setAutoRandom(true); }
      else {
        if(window.setAutoRandom)window.setAutoRandom(false);"""

UIPRO_ANCHOR="    try{localStorage.setItem('ql_size',sa.value);}catch(e){}\n  });"
UIPRO_NEW="""    try{localStorage.setItem('ql_size',sa.value);}catch(e){}\n  });
  /* 自主随机切换开关：关=锁定当前情绪（不再自动巡游），开=恢复自主状态机 */
  var autoRow=mk('div','row');
  autoRow.innerHTML='<label>自主随机切换</label><button id="autoRandBtn" style="flex:0 0 auto;padding:3px 14px;border-radius:12px;border:1px solid rgba(148,212,208,.4);background:rgba(148,212,208,.18);color:#EFFCFA;font-size:11px;cursor:pointer;font-family:inherit;">开</button>';
  var stateRowEl=document.getElementById('stateRow');
  if(stateRowEl)stateRowEl.parentNode.insertBefore(autoRow,stateRowEl);
  var abtn=autoRow.querySelector('#autoRandBtn');
  function renderAutoBtn(){var on=abtn.dataset.on==='1';abtn.textContent=on?'开':'关';abtn.style.background=on?'rgba(148,212,208,.18)':'rgba(255,255,255,.04)';abtn.style.color=on?'#EFFCFA':'#8FB5B1';abtn.style.borderColor=on?'rgba(148,212,208,.5)':'rgba(148,212,208,.25)';}
  window.setAutoRandom=function(on){abtn.dataset.on=on?'1':'0';renderAutoBtn();};
  abtn.dataset.on='1';renderAutoBtn();
  abtn.addEventListener('click',function(){
    var turnOn=abtn.dataset.on!=='1';
    if(turnOn){
      var rb=document.querySelector('#stateRow .statebtn[data-state="auto"]');
      if(rb)rb.click();
    }else{
      var cur=document.querySelector('#stateRow .statebtn.on');
      if(!cur||cur.dataset.state==='auto')cur=document.querySelector('#stateRow .statebtn[data-state="breathing"]');
      if(cur)cur.click();
    }
  });"""

def rep1(s, old, new, tag, fname):
    n=s.count(old)
    if n!=1: raise SystemExit('%s in %s: %d'%(tag,fname,n))
    return s.replace(old,new)

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    s=rep1(s,MAIN_OLD,MAIN_NEW,'main-handler',f)
    s=rep1(s,UIPRO_ANCHOR,UIPRO_NEW,'ui-toggle',f)
    open(f,'w',encoding='utf-8',newline='').write(s)
    # 语法自检
    ok=True
    for i,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0:
            ok=False; print(f,'block',i,'ERR:',r.stderr[:200])
    print(f,'round5 OK' if ok else f,'round5 SYNTAX FAIL')
import os
os.remove('_chk.js')
print('ROUND5 DONE')
