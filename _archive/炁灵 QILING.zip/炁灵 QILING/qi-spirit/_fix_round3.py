# -*- coding: utf-8 -*-
# 第三轮：① 粒子随机度可调（含关闭）② UI 专业化 + 全卡片可折叠
import os

# ---------- 1. 着色器：随机度 uniform ----------
R=[]
R.append(("uOpacity:{value:0.85},",
          "uOpacity:{value:0.85},\n        uRand:{value:0.45},"))
R.append(("        'attribute float aTint;',\n        'uniform float uSize;',",
          "        'attribute float aTint;',\n        'uniform float uSize;',\n        'uniform float uRand;',"))
R.append(("        '  gl_PointSize=uSize*aSize*uScale/max(0.1,-mv.z);',",
          "        '  float sz=1.0+(aSize-1.0)*uRand;',\n        '  gl_PointSize=uSize*sz*uScale/max(0.1,-mv.z);',"))
R.append(("        'uniform float uAdd;',\n        'varying float vSeed;',",
          "        'uniform float uAdd;',\n        'uniform float uRand;',\n        'varying float vSeed;',"))
R.append(("        '  vec3 col=mix(uColor,uColor2,vTint);',",
          "        '  float tw=vTint*uRand;',\n        '  vec3 col=mix(uColor,uColor2,tw*0.6);',"))
R.append(("        '  float vA=0.65+0.35*vTint;',",
          "        '  float vA=1.0-0.25*tw;',"))
R.append(("          u.uScale.value=(renderer.domElement.height||900)*0.5;",
          "          u.uScale.value=(renderer.domElement.height||900)*0.5;\n          u.uRand.value=(window.particleRand===undefined?0.45:window.particleRand);"))

# ---------- 2. UI Pro 注入脚本（CSS 精修 + DOM 重组成可折叠卡片组） ----------
UIPRO=r'''(function(){
'use strict';
var CSS=[
'#panel{width:238px !important;background:linear-gradient(180deg,rgba(8,20,19,.90),rgba(5,14,13,.94)) !important;border:1px solid rgba(148,212,208,.16) !important;border-radius:16px !important;padding:10px !important;box-shadow:0 14px 44px rgba(0,0,0,.5) !important;}',
'#panelHead{display:flex;align-items:center;justify-content:space-between;padding:2px 4px 8px;}',
'#panelHead h4{font-size:11px !important;letter-spacing:2.5px !important;color:#7FC9C4 !important;margin:0 !important;font-weight:600 !important;}',
'#btnFold{background:rgba(148,212,208,.10) !important;border:1px solid rgba(148,212,208,.25) !important;color:#A8DCD7 !important;border-radius:7px !important;}',
'#btnFold:hover{background:rgba(148,212,208,.22) !important;}',
'.cgroup{background:rgba(9,22,21,.55);border:1px solid rgba(148,212,208,.12);border-radius:11px;margin-bottom:7px;overflow:hidden;transition:border-color .2s ease,background .2s ease;}',
'.cgroup:hover{border-color:rgba(148,212,208,.28);}',
'.chead{display:flex !important;align-items:center;gap:8px;width:100%;padding:9px 12px !important;background:transparent !important;border:none !important;color:#A8DCD7 !important;font-size:11.5px !important;font-weight:600 !important;letter-spacing:.8px !important;cursor:pointer !important;text-align:left !important;font-family:inherit !important;margin:0 !important;}',
'.chead:hover{background:rgba(148,212,208,.06) !important;}',
'.chead .ctitle{flex:1;}',
'.chead .car{font-size:9px;color:rgba(148,212,208,.65);transition:transform .22s ease;transform-origin:center;}',
'.cgroup.collapsed .car{transform:rotate(-90deg);}',
'.cbody{padding:6px 10px 10px !important;}',
'.cgroup.collapsed .cbody{display:none;}',
'#quizWrap.cgroup,#boundwrap.cgroup{background:rgba(8,20,19,.78) !important;border:1px solid rgba(148,212,208,.14) !important;box-shadow:0 10px 32px rgba(0,0,0,.4);}',
'#quizWrap .cbody{padding:10px 12px !important;}',
'#boundwrap .cbody{padding:8px 12px 10px !important;}',
'#boundwrap h4.chead{border-radius:0 !important;}',
'.btn{font-size:12px !important;padding:8px 10px !important;border-radius:9px !important;background:rgba(148,212,208,.06) !important;border:1px solid rgba(148,212,208,.20) !important;color:#D7F0ED !important;margin-bottom:6px !important;transition:all .18s ease !important;}',
'.btn:hover{background:rgba(148,212,208,.15) !important;border-color:rgba(148,212,208,.42) !important;}',
'.statebtn{border-radius:8px !important;border-color:rgba(148,212,208,.16) !important;font-size:10.5px !important;padding:7px 2px !important;color:#8FB5B1 !important;background:rgba(255,255,255,.02) !important;transition:all .18s ease !important;}',
'.statebtn:hover{color:#D7F0ED !important;border-color:rgba(148,212,208,.4) !important;}',
'.statebtn.on{background:rgba(148,212,208,.16) !important;color:#EFFCFA !important;border-color:rgba(148,212,208,.55) !important;}',
'.particlebtn{background:rgba(255,255,255,.02) !important;border:1px solid rgba(148,212,208,.14) !important;transition:all .18s ease !important;}',
'.particlebtn:hover{border-color:rgba(148,212,208,.4) !important;}',
'.particlebtn.on{background:rgba(148,212,208,.13) !important;border-color:rgba(148,212,208,.5) !important;}',
'.skinbtn{border-radius:8px !important;border-color:rgba(148,212,208,.18) !important;background:rgba(255,255,255,.02) !important;color:#8FB5B1 !important;}',
'.skinbtn.on{background:rgba(148,212,208,.15) !important;color:#EFFCFA !important;}',
'#songSel,#quizCustom,#profileIO{background:rgba(5,14,13,.9) !important;border:1px solid rgba(148,212,208,.22) !important;}',
'.row label{color:#8FB5B1 !important;font-size:11px !important;letter-spacing:.4px !important;}',
'.row output{color:#7FC9C4 !important;}',
'input[type=range]{accent-color:#5FD4CC;}',
'#panel::-webkit-scrollbar{width:4px;}',
'#panel::-webkit-scrollbar-thumb{background:rgba(148,212,208,.22);border-radius:4px;}',
'#panel::-webkit-scrollbar-track{background:transparent;}',
'#topbar #state{backdrop-filter:blur(10px);border-color:rgba(148,212,208,.3) !important;}',
'#hint{font-size:10px !important;color:rgba(160,200,196,.5) !important;}',
'#vRaw,#vMap,#vR{color:#A8DCD7 !important;}'
].join('\n');
var st=document.createElement('style'); st.id='uiProStyle'; st.textContent=CSS; document.head.appendChild(st);

/* ---- 粒子随机度（0=关闭随机：均匀尺寸+统一颜色） ---- */
window.particleRand=parseFloat((function(){try{return localStorage.getItem('ql_rand');}catch(e){return null;}})()||'0.45');
function persistG(id,open){try{var s=JSON.parse(localStorage.getItem('ql_groups')||'{}');s[id]=open;localStorage.setItem('ql_groups',JSON.stringify(s));}catch(e){}}
function isOpen(id,def){try{var s=JSON.parse(localStorage.getItem('ql_groups')||'{}');if(id in s)return s[id];}catch(e){}return def;}
function mk(t,c,h){var e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;}
function wireHead(g,id,h){h.addEventListener('click',function(){g.classList.toggle('collapsed');persistG(id,!g.classList.contains('collapsed'));});}

function makeGroup(id,title,defOpen,nodes){
  var open=isOpen(id,defOpen);
  var g=mk('div','cgroup'+(open?'':' collapsed'));
  var h=mk('button','chead','<span class="ctitle">'+title+'</span><span class="car">▼</span>');
  var b=mk('div','cbody');
  nodes.forEach(function(n){if(n)b.appendChild(n);});
  g.appendChild(h);g.appendChild(b);
  wireHead(g,id,h);
  g.dataset.gid=id;
  return g;
}

/* ---- 重组右侧控制面板 ---- */
var panel=document.getElementById('panel');
if(panel && !panel.dataset.uipro){
  panel.dataset.uipro='1';
  var head=document.getElementById('panelHead');
  var byId=function(i){return document.getElementById(i);};
  function labelByPrefix(prefix){
    var kids=[].slice.call(panel.children);
    for(var i=0;i<kids.length;i++){
      var d=kids[i];
      if(d.tagName==='DIV'&&!d.id&&!d.className&&d.textContent.indexOf(prefix)===0)return d;
    }
    return null;
  }
  var gAudio=makeGroup('audio','🎵 音频输入',false,[
    byId('btnMusic'),byId('songSel')?byId('songSel').parentNode:null,
    byId('btnBeat'),byId('btnUpload'),byId('btnMic'),byId('fileInput')]);
  var gEmo=makeGroup('emo','💗 情绪预览',true,[labelByPrefix('状态 · 情绪预览'),byId('stateRow')]);
  var gExt=makeGroup('ext','🧪 扩展形态库',false,[labelByPrefix('扩展形态库'),byId('extRow')]);
  var gSkin=makeGroup('skin','🎨 视觉皮肤',false,[labelByPrefix('视觉皮肤'),byId('skinRow')]);
  var gPt=makeGroup('pt','✨ 粒子效果',true,[labelByPrefix('粒子效果'),byId('particleRow')]);
  var gParam=makeGroup('param','🎛 参数',false,[
    byId('sensitivity')?byId('sensitivity').closest('.row'):null,
    byId('boundR')?byId('boundR').closest('.row'):null]);
  /* 随机度滑杆 */
  var randRow=mk('div','row');
  randRow.innerHTML='<label>随机度（0=关闭随机）</label><input type="range" id="randAmt" min="0" max="1" step="0.05" value="'+window.particleRand+'"><output>'+Math.round(window.particleRand*100)+'%</output>';
  gPt.querySelector('.cbody').appendChild(randRow);
  var ra=randRow.querySelector('input');
  ra.addEventListener('input',function(){
    window.particleRand=parseFloat(ra.value);
    randRow.querySelector('output').textContent=Math.round(window.particleRand*100)+'%';
    try{localStorage.setItem('ql_rand',ra.value);}catch(e){}
  });
  [].slice.call(panel.children).forEach(function(c){if(c!==head)panel.removeChild(c);});
  [gAudio,gEmo,gExt,gSkin,gPt,gParam].forEach(function(g){panel.appendChild(g);});
}

/* ---- 盲测卡收起/展开 ---- */
var qw=document.getElementById('quizWrap');
if(qw && !qw.dataset.uipro){
  qw.dataset.uipro='1';
  var h4=qw.querySelector('h4');
  var qh=mk('button','chead','<span class="ctitle">🎯 情绪识别 · 盲测</span><span class="car">▼</span>');
  if(h4)h4.parentNode.replaceChild(qh,h4);
  var qb=mk('div','cbody');
  [].slice.call(qw.children).forEach(function(c){if(c!==qh)qb.appendChild(c);});
  qw.appendChild(qb);
  qw.classList.add('cgroup');
  if(!isOpen('quiz',false))qw.classList.add('collapsed');
  wireHead(qw,'quiz',qh);
}

/* ---- SAFETY GATE 卡收起/展开 ---- */
var bw=document.getElementById('boundwrap');
if(bw && !bw.dataset.uipro){
  bw.dataset.uipro='1';
  var bh4=bw.querySelector('h4');
  var bhd=mk('button','chead','<span class="ctitle">双向约束 · SAFETY GATE</span><span class="car">▼</span>');
  if(bh4)bh4.parentNode.replaceChild(bhd,bh4);
  var bb=mk('div','cbody');
  [].slice.call(bw.children).forEach(function(c){if(c!==bhd)bb.appendChild(c);});
  bw.appendChild(bb);
  bw.classList.add('cgroup');
  if(!isOpen('gate',false))bw.classList.add('collapsed');
  wireHead(bw,'gate',bhd);
}
})();'''

def rep1(s, old, new, tag, fname):
    n=s.count(old)
    if n!=1: raise SystemExit('%s in %s: %d occurrences'%(tag,fname,n))
    return s.replace(old,new)

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    for old,new in R:
        s=rep1(s,old,new,'shader:'+old[:30],f)
    inject='<script>\n'+UIPRO+'\n</script>\n</body>'
    s=rep1(s,'</body>',inject,'ui-pro',f)
    open(f,'w',encoding='utf-8',newline='').write(s)
    print(f,'round3 OK,',len(s)//1024,'KB')
print('ROUND3 DONE')
