# -*- coding: utf-8 -*-
# 桃花水母：脉冲推进动力学（收缩喷进→被动漂移→微沉，球内约束）+ 伞盖收缩脉冲
import re, subprocess, time

pairs=[
("""        'uniform float uCloudR;',
        'uniform float uTime;',""",
 """        'uniform float uCloudR;',
        'uniform float uJelly;',
        'uniform float uTime;',"""),
("""        '  float sz=1.0+(aSize-1.0)*uRand;',""",
 """        '  float sz=1.0+(aSize-1.0)*uRand;',
        '  float jPulse=1.0;',
        '  if(uJelly>0.5){',
        '    float jper=1.7+1.5*fract(aSeed*4.31);',
        '    float jc=fract(uTime/jper+aSeed);',
        '    jPulse=1.0-0.25*sin(min(jc/0.3,1.0)*3.14159)*step(jc,0.3);',
        '  }',"""),
("        '  gl_PointSize=uSize*sz*vBlinkSize*uScale/max(0.1,-mv.z);',",
 "        '  gl_PointSize=uSize*sz*vBlinkSize*jPulse*uScale/max(0.1,-mv.z);',"),
("          u.uBlink.value=(_tex&&_tex.name==='firefly')?1:0;",
 """          u.uBlink.value=(_tex&&_tex.name==='firefly')?1:0;
          u.uJelly.value=(_tex&&_tex.name==='jelly')?1:0;"""),
("  var ffHome=null; // 萤火虫模式：固定悬停位置",
 "  var ffHome=null; // 萤火虫模式：固定悬停位置\n  var jjSeed=null, jjVel=null; // 桃花水母模式：脉冲推进状态"),
("""        P[f3+2]+=(ffHome[f3+2]-P[f3+2])*0.06;
      }
    }""",
 """        P[f3+2]+=(ffHome[f3+2]-P[f3+2])*0.06;
      }
    }
    // 桃花水母模式：有约束的脉冲动力学——收缩推进窗（快）→被动漂移→轻微下沉，禁锢在云团球内
    if(currentParticleKey==='jelly'){
      if(!jjSeed){
        jjSeed=new Float32Array(COUNT); jjVel=new Float32Array(COUNT*3);
        for(var ji=0;ji<COUNT;ji++){ jjSeed[ji]=Math.random(); }
      }
      for(var jj=0;jj<COUNT;jj++){
        var j3=jj*3, js=jjSeed[jj];
        var jper=1.7+1.5*((js*4.31)%1);
        var jc=((t/jper)+js)%1;
        var jth=(jc<0.3)?Math.sin(jc/0.3*Math.PI):0;
        var jwa=t*0.05+js*37.0;
        var jpow=jth*(0.5+0.5*js);
        jjVel[j3]+=Math.cos(jwa)*0.35*jpow*0.014;
        jjVel[j3+1]+=0.85*jpow*0.014;
        jjVel[j3+2]+=Math.sin(jwa)*0.35*jpow*0.014;
        jjVel[j3]*=0.955; jjVel[j3+1]*=0.955; jjVel[j3+2]*=0.955;
        jjVel[j3+1]-=0.00045;
        var jx=P[j3]+jjVel[j3], jy=P[j3+1]+jjVel[j3+1], jz=P[j3+2]+jjVel[j3+2];
        var jr2=jx*jx+jy*jy+jz*jz;
        if(jr2>1.44){ var jk=1.2/Math.sqrt(jr2); jx*=jk; jy*=jk; jz*=jk; }
        P[j3]=jx; P[j3+1]=jy; P[j3+2]=jz;
      }
    }"""),
]

def apply_file(f, tries=4):
    for attempt in range(tries):
        try:
            s=open(f,encoding='utf-8').read()
            for old,new in pairs:
                n=s.count(old)
                if n!=1: raise RuntimeError('x%d: %s'%(n,old[:36]))
            for old,new in pairs:
                s=s.replace(old,new)
            open(f,'w',encoding='utf-8',newline='').write(s)
            bad=0
            for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
                open('_chki.js','w',encoding='utf-8').write(b)
                r=subprocess.run(['node','--check','_chki.js'],capture_output=True,text=True)
                if r.returncode!=0: bad+=1
            return 'PASS' if bad==0 else 'SYNTAX FAIL'
        except RuntimeError as e:
            if attempt==tries-1: return 'FAILED %s'%e
            time.sleep(1.2)
import os
for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    print(f,'->',apply_file(f))
if os.path.exists('_chki.js'): os.remove('_chki.js')
print('ROUND19 DONE')
