# -*- coding: utf-8 -*-
# 第十七轮：桃花水母从扩展形态降为贴图素材；bloom 形态移除；新增 jelly 粒子素材
import re, subprocess, time

pairs=[
# 1 移除 bloom 扩展形态注册
("  var EXT_MOTIONS=['tornado','school','manta','klein','wave','engulf','bloom','blackhole','firefly'];",
 "  var EXT_MOTIONS=['tornado','school','manta','klein','wave','engulf','blackhole','firefly'];"),
("""    bloom:    {emo:'桃花水母',icon:'🌸'},
""", ""),
("engulf:'#4F7CF0',bloom:'#FF8FBC',blackhole:'#FFB04A'",
 "engulf:'#4F7CF0',blackhole:'#FFB04A'"),
# 2 移除扩展形态库按钮（demo 无属性；index 由正则处理）
("    <button class=\"statebtn\" data-state=\"bloom\">🌸 桃花水母</button>\n", ""),
# 3 新增 jelly 贴图素材注册
("    firefly:   {count:9000, size:0.08, opacity:0.35, additive:1, blink:1}",
 """    jelly:     {count:800,  size:0.42, opacity:0.55, additive:0},
    firefly:   {count:9000, size:0.08, opacity:0.35, additive:1, blink:1}"""),
# 4 粒子效果卡新增按钮（fiber 之后，正则容错）
]

def apply_file(f, tries=4):
    for attempt in range(tries):
        try:
            s=open(f,encoding='utf-8').read()
            for old,new in pairs:
                n=s.count(old)
                if n!=1: raise RuntimeError('x%d: %s'%(n,old[:36]))
            for old,new in pairs:
                s=s.replace(old,new)
            # jelly 按钮：插在 fiber 按钮后；缩略图由加载器注入（与其它 dataURL 素材一致）
            BTN_RE=re.compile(r'(<button class="particlebtn" data-particle="fiber"[^>]*>[\s\S]*?</button>)')
            btn='\\1\n    <button class="particlebtn" data-particle="jelly"><span class="thumb"></span><span class="lbl">桃花水母</span></button>'
            s,n=BTN_RE.subn(btn, s, count=1)
            if n!=1: raise RuntimeError('jelly btn')
            open(f,'w',encoding='utf-8',newline='').write(s)
            bad=0
            for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
                open('_chkf.js','w',encoding='utf-8').write(b)
                r=subprocess.run(['node','--check','_chkf.js'],capture_output=True,text=True)
                if r.returncode!=0: bad+=1
            return 'PASS' if bad==0 else 'SYNTAX FAIL'
        except RuntimeError as e:
            if attempt==tries-1: return 'FAILED %s'%e
            time.sleep(1.2)
import os
for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    print(f,'→',apply_file(f))
if os.path.exists('_chkf.js'): os.remove('_chkf.js')
print('ROUND18 structural DONE')
