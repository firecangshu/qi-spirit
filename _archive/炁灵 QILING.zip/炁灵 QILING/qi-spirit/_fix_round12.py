# -*- coding: utf-8 -*-
# 萤火虫拟真优化：物种级闪光模式（单闪/双闪/脉冲串）+ 快起慢衰包络 + 空气透视 + 时走时停 + 静态漂移
import re, subprocess

REPL=[
# 1 顶点声明：加 vDepth
("""        'uniform float uCloudR;',
        'varying float vSeed;',""",
 """        'uniform float uCloudR;',
        'varying float vDepth;',
        'varying float vSeed;',"""),
# 2 顶点计算：视深（空气透视）
("""        '  float rr=length(position)/max(0.15,uCloudR);',
        '  vEdge=1.0-smoothstep(0.72,1.32,rr);',""",
 """        '  float rr=length(position)/max(0.15,uCloudR);',
        '  vEdge=1.0-smoothstep(0.72,1.32,rr);',
        '  vDepth=clamp((-mv.z-3.5)/7.0,0.0,1.0);',"""),
# 3 片元声明
("""        'varying float vEdge;',
        'void main(){',""",
 """        'varying float vEdge;',
        'varying float vDepth;',
        'void main(){',"""),
# 4 闪光模型：物种级模式（单闪/双闪/三连脉冲串）+ 快起慢衰 + 空气透视
("""        '  float blink=1.0;',
        '  if(uBlink>0.5){',
        '    float per=6.0+6.0*fract(vSeed*3.71);',                       // 每只周期 6~12 秒
        '    float cyc=fract(uTime/per+vSeed);',                           // 各自相位
        '    float breathe=0.02+0.06*sin(uTime*(0.5+1.7*fract(vSeed*7.31))+vTint*6.2832);', // 呼吸微光：若隐若现
        '    float flash=smoothstep(0.02,0.05,cyc)*smoothstep(0.12,0.06,cyc);',           // 每周期只点亮约 4% 时间
        '    blink=breathe+flash;',
        '  }',""",
 """        '  float blink=1.0;',
        '  if(uBlink>0.5){',
        '    float per=5.0+4.0*fract(vSeed*3.71);',                                      // 周期 5~9 秒（Photinus pyralis 典型值）
        '    float cyc=fract(uTime/per+vSeed);',
        '    float breathe=0.02+0.05*sin(uTime*(0.5+1.7*fract(vSeed*7.31))+vTint*6.2832);', // 呼吸微光
        '    float kind=fract(vSeed*9.17);',                                             // 物种级闪光模式
        '    float g1=smoothstep(0.0,0.015,cyc)*(1.0-smoothstep(0.015,0.12,cyc));',      // 快起慢衰单闪
        '    float g2=smoothstep(0.28,0.30,cyc)*(1.0-smoothstep(0.30,0.42,cyc));',
        '    float g3=smoothstep(0.15,0.17,cyc)*(1.0-smoothstep(0.17,0.29,cyc));',
        '    float env=kind<0.55?g1:(kind<0.80?max(g1,g2):max(g1,max(g2,g3)));',         // 单闪/双闪/三连脉冲串
        '    blink=(breathe+env)*(1.0-vDepth*0.45);',                                    // 空气透视：远处更暗
        '  }',"""),
# 5 静态个体：微颤 + 缓慢漂移（悬停的萤火虫并非钉死）
("""        var fjx=Math.sin(t*(0.6+(fj%7)*0.13)+fj)*fw, fjy=Math.cos(t*(0.5+(fj%5)*0.17)+fj*1.3)*fw;""",
 """        var fjx=Math.sin(t*(0.6+(fj%7)*0.13)+fj)*fw+Math.sin(t*0.11+fj*0.7)*0.05;   // 微颤+缓慢漂移
        var fjy=Math.cos(t*(0.5+(fj%5)*0.17)+fj*1.3)*fw+Math.cos(t*0.09+fj*1.1)*0.04;"""),
# 6 飞行个体：时走时停（悬停-窜行），窜行时略上扬
("""      var wx=Math.sin(t*(0.16+s1*0.30)+s1*47.0)*R+Math.sin(t*1.07+s3*9.0)*0.16;
      var wy=Math.sin(t*(0.13+s2*0.26)+s2*47.0)*0.62+Math.cos(t*0.83+s1*7.0)*0.14;
      var wz=Math.cos(t*(0.15+s3*0.28)+s3*47.0)*R;""",
 """      var burst=0.18+0.82*Math.pow(0.5+0.5*Math.sin(t*(0.22+s2*0.20)+s3*20.0),3.0); // 时走时停
      var wx=Math.sin(t*(0.16+s1*0.30)+s1*47.0)*R*burst+Math.sin(t*1.07+s3*9.0)*0.16;
      var wy=Math.sin(t*(0.13+s2*0.26)+s2*47.0)*0.62*burst+Math.cos(t*0.83+s1*7.0)*0.14+0.08*burst; // 窜行略上扬
      var wz=Math.cos(t*(0.15+s3*0.28)+s3*47.0)*R*burst;"""),
]

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    for i,(old,new) in enumerate(REPL):
        n=s.count(old)
        if n!=1: raise SystemExit('R%d in %s: %d'%(i,f,n))
        s=s.replace(old,new)
    open(f,'w',encoding='utf-8',newline='').write(s)
    bad=0
    for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0: bad+=1; print(f,k,r.stderr[:200])
    print(f,'firefly-pro OK, syntax','PASS' if bad==0 else 'FAIL')
import os; os.remove('_chk.js')
print('ROUND12 DONE')
