# -*- coding: utf-8 -*-
# 刷新三个文件内嵌的 PARTICLE_IMG dataURL（含新柔光尘）
import re, os, base64, io
from PIL import Image
KEYS={
 '柔光生命核.png':'softglow','半透明活体膜.png':'membrane','褶皱金属碎箔.png':'metalfoil',
 '柔性哑光金属甲片.png':'matteplate','多孔细胞甲片.png':'cellplate','光纤种子.png':'fiber',
 'particle_softglow_256.png':'dust'}
entries=[]
for f,key in KEYS.items():
    im=Image.open(os.path.join('assets/particle',f)).convert('RGBA')
    if im.size!=(256,256): im=im.resize((256,256), Image.LANCZOS)
    buf=io.BytesIO(); im.save(buf,'PNG',optimize=True)
    entries.append('  %s:"data:image/png;base64,%s"'%(key, base64.b64encode(buf.getvalue()).decode()))
new_data='var PARTICLE_IMG={\n'+',\n'.join(entries)+'\n};'
BS=chr(92)
for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    s,n=re.subn(r'var PARTICLE_IMG=\{[^}]*\};', new_data.replace(BS,BS+BS), s, count=1)
    assert n==1, f
    open(f,'w',encoding='utf-8',newline='').write(s)
    print(f,'dataURL refreshed')
