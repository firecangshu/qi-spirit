# -*- coding: utf-8 -*-
# 第九轮：劲舞式节奏编舞 —— 自相关测BPM + 相位锁定 + 节拍网格动作母题
import re, subprocess

REPL=[
# 1 状态变量：加节拍计数/动作母题/包络历史
("  var bpm=0, beatPhase=0, lastKickT=-1, lastSnareT=-1, lastHatT=-1, kickGapEma=0, lastInfoT=0;",
 "  var bpm=0, beatPhase=0, lastKickT=-1, lastSnareT=-1, lastHatT=-1, kickGapEma=0, lastInfoT=0;\n  var beatCount=0, danceMotif=0, envBuf=null, envHead=0, envFill=0, bpmCheckT=0; // 节拍网格与编舞状态"),
# 2 自相关测 BPM（librosa/Autostepper 同思路：起音包络自相关 + 倍频加固 + 滞回）
("""    if((onE||onF)&&now-lastBeatT>0.20){
      var bgap=now-lastBeatT; lastBeatT=now; beatEnv=1;
      if(bgap>0.30&&bgap<1.15){ beatGapEma=beatGapEma?beatGapEma*0.7+bgap*0.3:bgap; bpm=60/beatGapEma; }""",
 """    // ---- 节拍网格：起音包络历史 + 自相关测 BPM（每1.5s刷新一次，带倍频加固与滞回）----
    if(!envBuf){ envBuf=new Float32Array(480); envHead=0; envFill=0; bpmCheckT=0; }
    envBuf[envHead]=fluxV*0.6+bodyE*0.4; envHead=(envHead+1)%480; if(envFill<480)envFill++;
    bpmCheckT+=STEP;
    if(bpmCheckT>1.5&&envFill>180){
      bpmCheckT=0;
      var best=0,bestScore=-1;
      for(var bp=70;bp<=180;bp+=1){
        var L=Math.round(60/bp/STEP);
        if(L<8||L>=envFill-8) continue;
        var sc=0;
        for(var i2=0;i2<envFill-L;i2++){ sc+=envBuf[(envHead-1-i2+480)%480]*envBuf[(envHead-1-i2-L+480)%480]; }
        sc/=(envFill-L);
        var L2=L*2; var sc2=0;
        if(L2<envFill-8){ for(var i3=0;i3<envFill-L2;i3++){ sc2+=envBuf[(envHead-1-i3+480)%480]*envBuf[(envHead-1-i3-L2+480)%480]; } sc2/=(envFill-L2); sc+=sc2*0.5; }
        if(bpm>0){ sc*=1-0.35*Math.min(1,Math.abs(Math.log(bp/bpm)/Math.LN2)*0.5); }
        if(sc>bestScore){bestScore=sc;best=bp;}
      }
      if(best>0) bpm=bpm*0.6+best*0.4;
    }
    if((onE||onF)&&now-lastBeatT>0.20){
      var bgap=now-lastBeatT; lastBeatT=now; beatEnv=1;
      // 相位锁定：每次起音向最近的网格点轻推（逐步对齐）
      if(bpm>0){ var ph=beatPhase%1; var pherr=Math.min(ph,1-ph); beatPhase=(beatPhase+(ph<0.5?-pherr:pherr)*0.12+1)%1; }"""),
# 3 节拍计数 + 8 拍换动作母题
("""    beatPhase=(beatPhase+STEP/(bpm?60/bpm:0.5))%1;""",
 """    var prevPh=beatPhase;
    beatPhase=(beatPhase+STEP/(bpm?60/bpm:0.5))%1;
    if(beatPhase<prevPh){ beatCount++; if(beatCount%8===0){ danceMotif=(danceMotif+1+((Math.random()*2)|0))%4; } }"""),
# 4 动作母题：正拍触发的编舞量（脉冲/摆动/旋身/弹跳）
("""    var groove=audioOn?Math.sin(beatPhase*6.2831853):0;""",
 """    var groove=audioOn?Math.sin(beatPhase*6.2831853):0;
    // ==== 劲舞式编舞：4/4 强弱拍 + 每 8 拍切换动作母题（脉冲/摆动/旋身/弹跳）====
    var beatAcc=audioOn?[1,0.55,0.8,0.55][beatCount%4]:1;
    var onBeatE=audioOn?Math.max(0,1-beatPhase*2.4):0;
    var danceDir=(beatCount%2)?1:-1;
    var motifPulse=audioOn&&danceMotif===0?(0.5+0.6*beatAcc)*onBeatE:0;
    var motifSway =audioOn&&danceMotif===1?danceDir*onBeatE*0.36:0;
    var motifTwist=audioOn&&danceMotif===2?danceDir*onBeatE*0.5:0;
    var motifBounce=audioOn&&danceMotif===3?-onBeatE*0.20:0;"""),
# 5 脉冲编舞并入冲击
("    var pulseBoost=beatHit*0.10+kickPunch*0.16;                 // 底鼓：明显径向冲击",
 "    var pulseBoost=beatHit*0.10+kickPunch*0.16*(0.7+0.5*beatAcc)+motifPulse*0.20; // 底鼓：明显径向冲击（强拍加权）"),
# 6 摆动编舞并入
("    var audioSwayX=audioOn?(Math.sin(t*1.7)*melSwell*0.30+snareFlick*0.22*Math.sin(t*3.1)):0; // 整体随旋律/军鼓左右轻摇",
 "    var audioSwayX=audioOn?(Math.sin(t*1.7)*melSwell*0.30+snareFlick*0.22*Math.sin(t*3.1)):0; // 整体随旋律/军鼓左右轻摇\n    if(audioOn) audioSwayX+=motifSway; // 编舞摆动"),
# 7 弹跳编舞并入 y 偏移
("    var yOffset=sp.sink*BOUND;",
 "    var yOffset=sp.sink*BOUND+(audioOn?motifBounce:0); // 编舞弹跳（节拍下压）"),
# 8 旋身编舞并入切向角
("      if(audioOn) ang+=snareFlick*baseR[i]*2.2+groove*0.05*baseR[i]; // 军鼓沿切向甩、卡拍微旋",
 "      if(audioOn) ang+=snareFlick*baseR[i]*2.2+groove*0.05*baseR[i]+motifTwist*0.5*baseR[i]; // 军鼓甩/卡拍微旋/编舞旋身"),
]

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    for i,(old,new) in enumerate(REPL):
        n=s.count(old)
        if n!=1: raise SystemExit('R%d in %s: %d'%(i,f,n))
        s=s.replace(old,new)
    open(f,'w',encoding='utf-8',newline='').write(s)
    bad=0
    for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0: bad+=1; print(f,k,r.stderr[:200])
    print(f,'dance OK, syntax','PASS' if bad==0 else 'FAIL')
import os; os.remove('_chk.js')
print('ROUND10 DONE')
