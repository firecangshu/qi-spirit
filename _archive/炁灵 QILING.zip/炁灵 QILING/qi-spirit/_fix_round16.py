# -*- coding: utf-8 -*-
# 第十六轮：萤火虫从"贴图素材"升格为"扩展形态"（与龙卷风/沙丁鱼群平级），消除模式污染
import re, subprocess, time

pairs=[
# 1 注册为扩展形态
("  var EXT_MOTIONS=['tornado','school','manta','klein','wave','engulf','bloom','blackhole'];",
 "  var EXT_MOTIONS=['tornado','school','manta','klein','wave','engulf','bloom','blackhole','firefly'];"),
("""    blackhole:{emo:'黑洞',  icon:'🕳'}
  };""",
 """    blackhole:{emo:'黑洞',  icon:'🕳'},
    firefly:  {emo:'萤火虫',icon:'✨'}
  };"""),
("  var EXT_COLOR={tornado:'#A9C3D2',school:'#58C8E6',geese:'#FFB454',manta:'#B98CFF',klein:'#7BE0D6',wave:'#74E3FF',engulf:'#4F7CF0',bloom:'#FF8FBC',blackhole:'#FFB04A'};",
 "  var EXT_COLOR={tornado:'#A9C3D2',school:'#58C8E6',geese:'#FFB454',manta:'#B98CFF',klein:'#7BE0D6',wave:'#74E3FF',engulf:'#4F7CF0',bloom:'#FF8FBC',blackhole:'#FFB04A',firefly:'#D9F27E'};"),
# 2 扩展形态库按钮（黑洞之后）
("    <button class=\"statebtn\" data-state=\"blackhole\">🕳 黑洞</button>",
 "    <button class=\"statebtn\" data-state=\"blackhole\">🕳 黑洞</button>\n    <button class=\"statebtn\" data-state=\"firefly\">✨ 萤火虫</button>"),
# 3 形态参数（位置由 ffHome 覆盖，这里只给安静的底参数）
("""      case 'implode':     // 害羞：极小极密的亮核，向内缩、像把自己藏起来
        p.mode='implode'; p.corePow=2.4; p.flow=0.10; p.spin=0.001; p.label=tag; break;""",
 """      case 'implode':     // 害羞：极小极密的亮核，向内缩、像把自己藏起来
        p.mode='implode'; p.corePow=2.4; p.flow=0.10; p.spin=0.001; p.label=tag; break;
      case 'firefly':     // 萤火虫：固定悬停+闪烁，少数个体带彗尾飞行（位置由 ffHome 覆盖）
        p.mode='flow'; p.flow=0; p.spin=0; p.tremor=0; p.label=tag; break;"""),
# 4 模式判定改为按形态（原为按贴图）
("    if(currentParticleKey==='firefly'){",
 "    if(stateName==='firefly'){"),
("      if(points&&currentParticleKey!=='firefly') points.rotation.y+=sp.spin+flowSpeed*0.0004;",
 "      if(points&&stateName!=='firefly') points.rotation.y+=sp.spin+flowSpeed*0.0004;"),
# 5 渲染循环与贴图解析：萤火虫形态强制萤火虫贴图（优先于手动锁定）
("          var _k=currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skin,stateName);",
 "          var _k=(stateName==='firefly')?'firefly':(currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skin,stateName));"),
("    var key=currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skinName, stateName);",
 "    var key=(stateName==='firefly')?'firefly':(currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skinName, stateName));"),
# 6 移除上一轮的"切形态退出萤火虫"补丁（现在萤火虫本身是形态，切换逻辑天然正确）
("""        if(currentParticleKey==='firefly'){ // 切形态即退出萤火虫（静态悬停会屏蔽形态运动）
          currentParticleKey='auto';
          document.querySelectorAll('.particlebtn').forEach(function(x){x.classList.toggle('on',x.dataset.particle==='auto');});
          if(useWebGL&&mat){ applyTextureToMaterial(mat, skin, stateName); }
        }""",
 ""),
("""    if(currentParticleKey==='firefly'){
      currentParticleKey='auto';
      document.querySelectorAll('.particlebtn').forEach(function(x){x.classList.toggle('on',x.dataset.particle==='auto');});
      if(useWebGL&&mat){ applyTextureToMaterial(mat, skin, stateName); }
    }
""",""),
# 7 粒子效果卡移除萤火虫按钮（升格为形态）
("""    <button class="particlebtn" data-particle="firefly"><span class="thumb" style="background-image:radial-gradient(circle at 50% 45%,#FFF3B0 0%,#C8E86A 45%,rgba(20,40,20,0) 78%);"></span><span class="lbl">萤火虫</span></button>\n""", ""),
# 8 ?pt=firefly 重定向到扩展形态
("""    var pm=(location.search.match(/[?&]pt=(\w+)/)||[])[1];
    if(pm){
      currentParticleKey=pm;
      setTimeout(function(){ var b=document.querySelector('.particlebtn[data-particle="'+pm+'"]'); if(b)b.click(); },400);
    }""",
 """    var pm=(location.search.match(/[?&]pt=(\w+)/)||[])[1];
    if(pm==='firefly'){ // 萤火虫已是扩展形态，?pt=firefly 自动转为形态切换
      setTimeout(function(){ var b=document.querySelector('#extRow .statebtn[data-state="firefly"]'); if(b)b.click(); },400);
    }else if(pm){
      currentParticleKey=pm;
      setTimeout(function(){ var b=document.querySelector('.particlebtn[data-particle="'+pm+'"]'); if(b)b.click(); },400);
    }"""),
]

def apply_file(f, tries=4):
    for attempt in range(tries):
        try:
            s=open(f,encoding='utf-8').read()
            for i,(old,new) in enumerate(pairs):
                n=s.count(old)
                if n!=1:
                    if i in (7,) and n==0 and 'particlebtn[data-particle="firefly"]' not in s:
                        continue  # 按钮已被并行工具移除则跳过
                    raise RuntimeError('R%d x%d: %s'%(i,n,old[:36]))
            for old,new in pairs:
                if s.count(old)==1: s=s.replace(old,new)
            open(f,'w',encoding='utf-8',newline='').write(s)
            bad=0
            for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
                open('_chka.js','w',encoding='utf-8').write(b)
                r=subprocess.run(['node','--check','_chka.js'],capture_output=True,text=True)
                if r.returncode!=0: bad+=1; print(f,k,r.stderr[:150])
            return 'PASS' if bad==0 else 'SYNTAX FAIL'
        except RuntimeError as e:
            if attempt==tries-1: return 'FAILED %s'%e
            time.sleep(1.2)
import os
for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    print(f,'→',apply_file(f))
if os.path.exists('_chka.js'): os.remove('_chka.js')
EOF
_MARKER_DONE_
