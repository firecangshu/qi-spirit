# -*- coding: utf-8 -*-
# 节拍跟踪修正：固定50Hz时间轴重采样 + 对数高斯节奏先验 + 真实帧间隔
import re, subprocess

REPL=[
# 1 变量补充
("  var beatCount=0, danceMotif=0, envBuf=null, envHead=0, envFill=0, bpmCheckT=0; // 节拍网格与编舞状态",
 "  var beatCount=0, danceMotif=0, envBuf=null, envHead=0, envFill=0, bpmCheckT=0, envT=0, __lastAn=0; // 节拍网格与编舞状态"),
# 2 网格核心：真实帧间隔重采样到 50Hz + librosa 式对数高斯先验
("""    // ---- 节拍网格：起音包络历史 + 自相关测 BPM（每1.5s刷新一次，带倍频加固与滞回）----
    if(!envBuf){ envBuf=new Float32Array(480); envHead=0; envFill=0; bpmCheckT=0; }
    envBuf[envHead]=fluxV*0.6+bodyE*0.4; envHead=(envHead+1)%480; if(envFill<480)envFill++;
    bpmCheckT+=STEP;
    if(bpmCheckT>1.5&&envFill>180){
      bpmCheckT=0;
      var best=0,bestScore=-1;
      for(var bp=70;bp<=180;bp+=1){
        var L=Math.round(60/bp/STEP);
        if(L<8||L>=envFill-8) continue;
        var sc=0;
        for(var i2=0;i2<envFill-L;i2++){ sc+=envBuf[(envHead-1-i2+480)%480]*envBuf[(envHead-1-i2-L+480)%480]; }
        sc/=(envFill-L);
        var L2=L*2; var sc2=0;
        if(L2<envFill-8){ for(var i3=0;i3<envFill-L2;i3++){ sc2+=envBuf[(envHead-1-i3+480)%480]*envBuf[(envHead-1-i3-L2+480)%480]; } sc2/=(envFill-L2); sc+=sc2*0.5; }
        if(bpm>0){ sc*=1-0.35*Math.min(1,Math.abs(Math.log(bp/bpm)/Math.LN2)*0.5); }
        if(sc>bestScore){bestScore=sc;best=bp;}
      }
      if(best>0) bpm=bpm*0.6+best*0.4;
    }""",
 """    // ---- 节拍网格：包络重采样到固定 50Hz 时间轴 + 自相关测 BPM（librosa 式先验，抗帧率波动与倍频歧义）----
    var _pn=performance.now();
    var dtReal=__lastAn?Math.min(0.1,Math.max(0.004,(_pn-__lastAn)/1000)):STEP;
    __lastAn=_pn;
    if(!envBuf){ envBuf=new Float32Array(480); envHead=0; envFill=0; bpmCheckT=0; envT=0; }
    envT+=dtReal;
    var lastEnv=fluxV*0.6+bodyE*0.4;
    while(envT>=0.02){ envBuf[envHead]=lastEnv; envHead=(envHead+1)%480; if(envFill<480)envFill++; envT-=0.02; }
    bpmCheckT+=dtReal;
    if(bpmCheckT>1.5&&envFill>180){
      bpmCheckT=0;
      var best=0,bestScore=-1;
      for(var bp=70;bp<=180;bp+=1){
        var L=Math.round(3000/bp);
        if(L<10||L>=envFill-10) continue;
        var sc=0;
        for(var i2=0;i2<envFill-L;i2++){ sc+=envBuf[(envHead-1-i2+480)%480]*envBuf[(envHead-1-i2-L+480)%480]; }
        sc/=(envFill-L);
        var L2=L*2; var sc2=0;
        if(L2<envFill-10){ for(var i3=0;i3<envFill-L2;i3++){ sc2+=envBuf[(envHead-1-i3+480)%480]*envBuf[(envHead-1-i3-L2+480)%480]; } sc2/=(envFill-L2); sc+=sc2*0.5; }
        sc*=Math.exp(-0.5*Math.pow(Math.log2(bp/115)/1.1,2)); // 对数高斯节奏先验（最常见速度~115BPM）
        if(bpm>0){ sc*=1-0.25*Math.min(1,Math.abs(Math.log(bp/bpm)/Math.LN2)*0.4); } // 轻滞回防跳变
        if(sc>bestScore){bestScore=sc;best=bp;}
      }
      if(best>0) bpm=bpm*0.5+best*0.5;
    }"""),
# 3 相位推进改用真实帧间隔（帧率波动不再拖慢/加快网格）
("""    var prevPh=beatPhase;
    beatPhase=(beatPhase+STEP/(bpm?60/bpm:0.5))%1;""",
 """    var prevPh=beatPhase;
    beatPhase=(beatPhase+dtReal/(bpm?60/bpm:0.5))%1;"""),
]

for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    for i,(old,new) in enumerate(REPL):
        n=s.count(old)
        if n!=1: raise SystemExit('R%d in %s: %d'%(i,f,n))
        s=s.replace(old,new)
    open(f,'w',encoding='utf-8',newline='').write(s)
    bad=0
    for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
        open('_chk.js','w',encoding='utf-8').write(b)
        r=subprocess.run(['node','--check','_chk.js'],capture_output=True,text=True)
        if r.returncode!=0: bad+=1; print(f,k,r.stderr[:200])
    print(f,'beatfix OK, syntax','PASS' if bad==0 else 'FAIL')
import os; os.remove('_chk.js')
print('ROUND10B DONE')
