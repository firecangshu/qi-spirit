# -*- coding: utf-8 -*-
# 第十八轮：萤火虫回归贴图素材（撤销形态升格），并修复拖尾占比滑杆被 ?tr= 永久覆盖的问题
import re, subprocess, time

pairs=[
# 1 撤销扩展形态注册
("  var EXT_MOTIONS=['tornado','school','manta','klein','wave','engulf','blackhole','firefly'];",
 "  var EXT_MOTIONS=['tornado','school','manta','klein','wave','engulf','blackhole'];"),
("""    blackhole:{emo:'黑洞',  icon:'🕳'},
    firefly:  {emo:'萤火虫',icon:'✨'}
  };""",
 """    blackhole:{emo:'黑洞',  icon:'🕳'}
  };"""),
("engulf:'#4F7CF0',blackhole:'#FFB04A',firefly:'#D9F27E'};",
 "engulf:'#4F7CF0',blackhole:'#FFB04A'};"),
# 2 移除扩展形态库按钮
("    <button class=\"statebtn\" data-state=\"firefly\">✨ 萤火虫</button>\n", ""),
# 3 移除形态参数 case
("""      case 'firefly':     // 萤火虫：固定悬停+闪烁，少数个体带彗尾飞行（位置由 ffHome 覆盖）
        p.mode='flow'; p.flow=0; p.spin=0; p.tremor=0; p.label=tag; break;
""", ""),
# 4 模式判定改回按贴图
("""    if(stateName==='firefly'){
      if(!ffHome){""",
 """    if(currentParticleKey==='firefly'){
      if(!ffHome){"""),
("      if(points&&stateName!=='firefly') points.rotation.y+=sp.spin+flowSpeed*0.0004;",
 "      if(points&&currentParticleKey!=='firefly') points.rotation.y+=sp.spin+flowSpeed*0.0004;"),
# 5 贴图解析改回手动优先
("          var _k=(stateName==='firefly')?'firefly':(currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skin,stateName));",
 "          var _k=currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skin,stateName);"),
("    var key=(stateName==='firefly')?'firefly':(currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skinName, stateName));",
 "    var key=currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skinName, stateName);"),
# 6 撤销 ?pt=firefly 重定向（恢复直达粒子素材）
("""    var pm=(location.search.match(/[?&]pt=(\\w+)/)||[])[1];
    if(pm==='firefly'){ // 萤火虫已是扩展形态：?pt=firefly 自动转为形态切换
      setTimeout(function(){ var b=document.querySelector('#extRow .statebtn[data-state="firefly"]'); if(b)b.click(); },400);
    }else if(pm){
      currentParticleKey=pm;
      setTimeout(function(){ var b=document.querySelector('.particlebtn[data-particle="'+pm+'"]'); if(b)b.click(); },400);
    }""",
 """    var pm=(location.search.match(/[?&]pt=(\\w+)/)||[])[1];
    if(pm){
      currentParticleKey=pm;
      setTimeout(function(){ var b=document.querySelector('.particlebtn[data-particle="'+pm+'"]'); if(b)b.click(); },400);
    }"""),
# 7 修拖尾占比滑杆：拖动即清除 ?tr= 覆盖，滑杆永远生效
("""    window.trailRatio=parseFloat(trIn.value);
    trRow.querySelector('output').textContent=Math.round(window.trailRatio*100)+'%';""",
 """    window.trailRatio=parseFloat(trIn.value);
    window.__trOverride=undefined;
    trRow.querySelector('output').textContent=Math.round(window.trailRatio*100)+'%';"""),
# 8 贴图素材区恢复萤火虫按钮（fiber 之后）
]

FF_BTN='    <button class="particlebtn" data-particle="firefly"><span class="thumb" style="background-image:radial-gradient(circle at 50% 45%,#FFF3B0 0%,#C8E86A 45%,rgba(20,40,20,0) 78%);"></span><span class="lbl">萤火虫</span></button>\n'
FB_RE=re.compile(r'(<button class="particlebtn" data-particle="fiber"[^>]*>[\s\S]*?</button>\n)')

def apply_file(f, tries=4):
    for attempt in range(tries):
        try:
            s=open(f,encoding='utf-8').read()
            for old,new in pairs:
                n=s.count(old)
                if n!=1: raise RuntimeError('x%d: %s'%(n,old[:36]))
            for old,new in pairs:
                s=s.replace(old,new)
            if 'data-particle="firefly"' not in s:
                s,n=FB_RE.subn(lambda m: m.group(1)+FF_BTN, s, count=1)
                if n!=1: raise RuntimeError('ff btn')
            open(f,'w',encoding='utf-8',newline='').write(s)
            bad=0
            for k,b in enumerate(re.findall(r'<script>(.*?)</script>', s, re.S)):
                open('_chkn.js','w',encoding='utf-8').write(b)
                r=subprocess.run(['node','--check','_chkn.js'],capture_output=True,text=True)
                if r.returncode!=0: bad+=1
            return 'PASS' if bad==0 else 'SYNTAX FAIL'
        except RuntimeError as e:
            if attempt==tries-1: return 'FAILED %s'%e
            time.sleep(1.2)
import os
for f in ['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']:
    print(f,'→',apply_file(f))
if os.path.exists('_chkn.js'): os.remove('_chkn.js')
print('ROUND19REVERT DONE')
