# -*- coding: utf-8 -*-
# 粒子渲染升级补丁：应用到三个正式文件
import io

VENDOR=['CopyShader.js','LuminosityHighPassShader.js','EffectComposer.js','RenderPass.js','ShaderPass.js','UnrealBloomPass.js']
vendor_js='\n'.join(open('vendor/'+v,encoding='utf-8').read() for v in VENDOR)
data_js=open('_textures_dataurl.js',encoding='utf-8').read()

OLD_SECTION_START='  // ================= 粒子贴图素材 ================='
OLD_SECTION_END='  // 粒子效果按钮：点击立即切换'

NEW_SECTION='''  // ================= 粒子贴图素材（dataURL 内嵌 + 256 POT mipmap + ShaderMaterial + Bloom） =================
  var PARTICLE_TEXTURES={};
  var currentParticleKey='auto';
  var PARTICLE_FILE={
    softglow:'柔光生命核.png',
    membrane:'半透明活体膜.png',
    metalfoil:'褶皱金属碎箔.png',
    matteplate:'柔性哑光金属甲片.png',
    cellplate:'多孔细胞甲片.png',
    fiber:'光纤种子.png'
  };
  // 素材渲染性格（ShaderMaterial 路径）：素材是完整大图案（整片碎箔/整个细胞），
  // additive=1 发光型走加法混合（大量小微粒叠出尘雾），additive=0 实体型走普通混合（少量中大精灵保形状）
  // count=WebGL 绘制数（drawRange），size=精灵世界尺寸，opacity=透明度
  var PARTICLE_RENDER={
    softglow:  {count:3200, size:0.13, opacity:0.28, additive:1},
    fiber:     {count:3000, size:0.10, opacity:0.45, additive:1},
    membrane:  {count:260,  size:0.85, opacity:0.42, additive:0},
    metalfoil: {count:340,  size:0.40, opacity:0.95, additive:0},
    matteplate:{count:400,  size:0.32, opacity:0.92, additive:0},
    cellplate: {count:300,  size:0.50, opacity:0.92, additive:0}
  };
  function loadParticleTextures(){
    if(typeof THREE==='undefined' || !THREE.TextureLoader || !window.PARTICLE_IMG) return;
    var loader=new THREE.TextureLoader();
    Object.keys(PARTICLE_IMG).forEach(function(key){
      loader.load(PARTICLE_IMG[key],function(tex){
        tex.name=key;
        // 内嵌前已重采样为 256×256（2 的幂）：可安全开启 mipmap 三线性过滤 + 各向异性，
        // 消除旧管线 NPOT 无法 mipmap 导致的缩小采样噪点/闪烁
        tex.minFilter=THREE.LinearMipmapLinearFilter;
        tex.magFilter=THREE.LinearFilter;
        tex.generateMipmaps=true;
        tex.wrapS=tex.wrapT=THREE.ClampToEdgeWrapping;
        try{ tex.anisotropy=renderer?renderer.capabilities.getMaxAnisotropy():4; }catch(e){}
        PARTICLE_TEXTURES[key]=tex;
        var thumb=document.querySelector('.particlebtn[data-particle="'+key+'"] .thumb');
        if(thumb) thumb.style.backgroundImage='url('+PARTICLE_IMG[key]+')';
        if(mat){ applyTextureToMaterial(mat, skin, stateName); }
      },undefined,function(err){ console.warn('粒子贴图加载失败:', key, err); });
    });
  }
  function resolveTextureKey(skinName, stateName){
    // 形态优先的轻量映射；未命中则回退到皮肤默认
    if(stateName){
      if(/tornado|blackhole|vortex|burst/.test(stateName)) return 'metalfoil';
      if(/thinking|klein/.test(stateName)) return 'cellplate';
      if(/manta|engulf|bloom|wave/.test(stateName)) return 'membrane';
    }
    if(skinName==='gel') return 'membrane';
    return 'softglow';
  }
  function makeShaderMat(tex){
    // 逐粒子：尺寸差异(aSize) / 随机旋转(aSeed) / 双色渐变(aTint)，在 GPU 上完成
    var additive=!!(PARTICLE_RENDER[tex.name]&&PARTICLE_RENDER[tex.name].additive);
    var m=new THREE.ShaderMaterial({
      uniforms:{
        uTex:{value:tex},
        uSize:{value:1.0},
        uScale:{value:450.0},
        uColor:{value:new THREE.Color(0x8FD6D1)},
        uColor2:{value:new THREE.Color(0xE8FFFB)},
        uOpacity:{value:0.85},
        uAdd:{value:additive?1:0}
      },
      vertexShader:[
        'attribute float aSize;',
        'attribute float aSeed;',
        'attribute float aTint;',
        'uniform float uSize;',
        'uniform float uScale;',
        'varying float vSeed;',
        'varying float vTint;',
        'void main(){',
        '  vSeed=aSeed; vTint=aTint;',
        '  vec4 mv=modelViewMatrix*vec4(position,1.0);',
        '  gl_PointSize=uSize*aSize*uScale/max(0.1,-mv.z);',
        '  gl_Position=projectionMatrix*mv;',
        '}'
      ].join('\\n'),
      fragmentShader:[
        'uniform sampler2D uTex;',
        'uniform vec3 uColor;',
        'uniform vec3 uColor2;',
        'uniform float uOpacity;',
        'uniform float uAdd;',
        'varying float vSeed;',
        'varying float vTint;',
        'void main(){',
        '  vec2 pc=gl_PointCoord-vec2(0.5);',
        '  float an=vSeed*6.2832;',
        '  float cs=cos(an), sn=sin(an);',
        '  pc=mat2(cs,-sn,sn,cs)*pc+vec2(0.5);',
        '  if(pc.x<0.0||pc.x>1.0||pc.y<0.0||pc.y>1.0) discard;',
        '  vec4 t=texture2D(uTex,pc);',
        '  if(t.a<0.02) discard;',
        '  vec3 col=mix(uColor,uColor2,vTint);',
        '  float vA=0.65+0.35*vTint;',
        '  if(uAdd>0.5){',
        '    gl_FragColor=vec4(col*t.r*t.a*uOpacity*vA,1.0);',
        '  } else {',
        '    gl_FragColor=vec4(col*(0.55+0.45*t.r), t.a*uOpacity*vA);',
        '  }',
        '}'
      ].join('\\n'),
      transparent:true,
      depthWrite:false,
      blending:additive?THREE.AdditiveBlending:THREE.NormalBlending
    });
    return m;
  }
  function applyTextureToMaterial(material, skinName, stateName){
    // 若用户手动锁定某素材，优先使用；否则按皮肤+形态自动映射
    var key=currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skinName, stateName);
    var tex=PARTICLE_TEXTURES[key];
    if(!tex) return;
    // 主路径：自定义 ShaderMaterial（逐粒子尺寸/旋转/渐变）
    if(points && geo && geo.attributes.aSize){
      var sm=makeShaderMat(tex);
      if(mat && mat!==sm && mat.dispose) mat.dispose();
      points.material=sm;
      mat=sm;
      return;
    }
    // 兜底：逐粒子属性不可用时退回 PointsMaterial 贴图
    material.map=tex;
    material.blending=(PARTICLE_RENDER[key]&&PARTICLE_RENDER[key].additive)?THREE.AdditiveBlending:THREE.NormalBlending;
    material.alphaTest=material.blending===THREE.NormalBlending?0.08:0.0;
    material.depthWrite=false;
    material.needsUpdate=true;
  }
'''

OLD_INIT='''    geo=new THREE.BufferGeometry();
    geo.setAttribute('position',new THREE.BufferAttribute(positions,3));
    mat=new THREE.PointsMaterial({color:0x8FD6D1,size:0.045,transparent:true,opacity:0.9,blending:THREE.AdditiveBlending,depthWrite:false});
    applyTextureToMaterial(mat, skin, stateName);
    points=new THREE.Points(geo,mat); scene.add(points);
  }'''
NEW_INIT='''    geo=new THREE.BufferGeometry();
    geo.setAttribute('position',new THREE.BufferAttribute(positions,3));
    // 逐粒子属性：尺寸差异/随机旋转相位/双色渐变权重（ShaderMaterial 使用；PointsMaterial 下无副作用）
    var aSize=new Float32Array(COUNT), aSeedA=new Float32Array(COUNT), aTintA=new Float32Array(COUNT);
    for(var ai=0;ai<COUNT;ai++){ aSize[ai]=0.55+Math.random()*0.95; aSeedA[ai]=Math.random(); aTintA[ai]=Math.random(); }
    geo.setAttribute('aSize',new THREE.BufferAttribute(aSize,1));
    geo.setAttribute('aSeed',new THREE.BufferAttribute(aSeedA,1));
    geo.setAttribute('aTint',new THREE.BufferAttribute(aTintA,1));
    mat=new THREE.PointsMaterial({color:0x8FD6D1,size:0.045,transparent:true,opacity:0.9,blending:THREE.AdditiveBlending,depthWrite:false});
    points=new THREE.Points(geo,mat); scene.add(points);
    applyTextureToMaterial(mat, skin, stateName);
    // UnrealBloom 后期辉光（内联 vendor，缺失时自动跳过）
    if(THREE.EffectComposer && THREE.UnrealBloomPass){
      composer=new THREE.EffectComposer(renderer);
      composer.addPass(new THREE.RenderPass(scene,camera));
      composer.addPass(new THREE.UnrealBloomPass(new THREE.Vector2(W,H),0.9,0.5,0.45));
    }
  }'''

OLD_MATBLOCK='''      if(mat){
        var hasMap=!!mat.map;
        // 颜色实时跟随情绪（curColor 0-255 → 0-1）
        mat.color.setRGB(curColor.r/255, curColor.g/255, curColor.b/255);
        if(hasMap){
          // 贴图模式：少量大精灵，素材形状清晰可见；数量/尺寸/透明度按素材性格配置
          var cfg=PARTICLE_STYLE[mat.map.name]||null;
          if(cfg){
            mat.size=cfg.size*(1+audioScale*0.25);
            mat.opacity=cfg.opacity;
            if(geo) geo.setDrawRange(0, Math.min(cfg.count, COUNT));
          }
        } else {
          if(geo) geo.setDrawRange(0, COUNT);
          if(skin==='swarm'){
            mat.size = 0.045+audioScale*0.03;
            mat.opacity = 0.9;
          } else {
            mat.size = 0.10+audioScale*0.05;
            mat.opacity = 0.35+mappedE*0.25;
          }
        }
      }
      renderer.render(scene,camera);'''
NEW_MATBLOCK='''      if(mat){
        if(mat.isShaderMaterial){
          // ShaderMaterial 路径：逐粒子属性已由 attribute 承担，只更新全局 uniform
          var u=mat.uniforms;
          var _k=currentParticleKey!=='auto'?currentParticleKey:resolveTextureKey(skin,stateName);
          var _tex=PARTICLE_TEXTURES[_k];
          var _cfg=_tex?PARTICLE_RENDER[_tex.name]:null;
          u.uColor.value.setRGB(curColor.r/255, curColor.g/255, curColor.b/255);
          u.uColor2.value.setRGB(Math.min(1,curColor.r/255*1.5+0.30), Math.min(1,curColor.g/255*1.5+0.34), Math.min(1,curColor.b/255*1.5+0.32));
          u.uSize.value=(_cfg?_cfg.size:(skin==='swarm'?0.075:0.16))*(1+audioScale*0.25);
          u.uOpacity.value=_cfg?_cfg.opacity:(skin==='swarm'?0.9:0.5);
          u.uScale.value=(renderer.domElement.height||900)*0.5;
          if(geo) geo.setDrawRange(0,_cfg?Math.min(_cfg.count,COUNT):COUNT);
        } else {
          var hasMap=!!mat.map;
          // 颜色实时跟随情绪（curColor 0-255 → 0-1）
          mat.color.setRGB(curColor.r/255, curColor.g/255, curColor.b/255);
          if(hasMap){
            var cfg=PARTICLE_RENDER[mat.map.name]||null;
            if(cfg){
              mat.size=cfg.size*(1+audioScale*0.25);
              mat.opacity=cfg.opacity;
              if(geo) geo.setDrawRange(0, Math.min(cfg.count, COUNT));
            }
          } else {
            if(geo) geo.setDrawRange(0, COUNT);
            if(skin==='swarm'){
              mat.size = 0.045+audioScale*0.03;
              mat.opacity = 0.9;
            } else {
              mat.size = 0.10+audioScale*0.05;
              mat.opacity = 0.35+mappedE*0.25;
            }
          }
        }
      }
      if(composer) composer.render(); else renderer.render(scene,camera);'''

OLD_SKIN='''      if(useWebGL&&mat){
        applyTextureToMaterial(mat, skin, stateName);
        mat.color.setHex(skin==='swarm'?0x8FD6D1:0x7EC8C2);
      }'''
NEW_SKIN='''      if(useWebGL&&mat){
        applyTextureToMaterial(mat, skin, stateName);
        if(!mat.isShaderMaterial) mat.color.setHex(skin==='swarm'?0x8FD6D1:0x7EC8C2);
      }'''

OLD_GLOB='  var points=null, geo=null, boundMesh=null, mat=null;'
NEW_GLOB='  var points=null, geo=null, boundMesh=null, mat=null, composer=null;'

OLD_RESIZE="if(useWebGL){ camera.aspect=W/H;camera.updateProjectionMatrix(); renderer.setSize(W,H); }"
NEW_RESIZE="if(useWebGL){ camera.aspect=W/H;camera.updateProjectionMatrix(); renderer.setSize(W,H); if(composer) composer.setSize(W,H); }"

def rep1(s, old, new, tag, fname):
    n=s.count(old)
    if n!=1:
        raise SystemExit('%s in %s: found %d occurrences'%(tag,fname,n))
    return s.replace(old,new)

files=['qiling_1.0_demo.html','index.html','qiling_10form_standalone.html']
for f in files:
    s=open(f,encoding='utf-8').read()
    i=s.index(OLD_SECTION_START); j=s.index(OLD_SECTION_END)
    s=s[:i]+NEW_SECTION+s[j:]
    s=rep1(s,OLD_INIT,NEW_INIT,'initWebGL',f)
    s=rep1(s,OLD_MATBLOCK,NEW_MATBLOCK,'matblock',f)
    s=rep1(s,OLD_SKIN,NEW_SKIN,'skin',f)
    s=rep1(s,OLD_GLOB,NEW_GLOB,'globals',f)
    s=rep1(s,OLD_RESIZE,NEW_RESIZE,'resize',f)
    if f=='qiling_1.0_demo.html':
        anchor='<script src="three.min.js"></script>'
        if s.count(anchor)!=1: raise SystemExit('anchor demo')
        inject=(anchor+'\n<script src="vendor/CopyShader.js"></script>\n'
                '<script src="vendor/LuminosityHighPassShader.js"></script>\n'
                '<script src="vendor/EffectComposer.js"></script>\n'
                '<script src="vendor/RenderPass.js"></script>\n'
                '<script src="vendor/ShaderPass.js"></script>\n'
                '<script src="vendor/UnrealBloomPass.js"></script>\n'
                '<script>\n'+data_js+'</script>')
        s=s.replace(anchor,inject)
    else:
        anchor="</script>\n<script>\n(function(){\n  'use strict';"
        if s.count(anchor)!=1: raise SystemExit('anchor '+f+': %d'%s.count(anchor))
        inject=("</script>\n<script>\n"+vendor_js+"\n</script>\n<script>\n"
                +data_js+"</script>\n<script>\n(function(){\n  'use strict';")
        s=s.replace(anchor,inject)
    open(f,'w',encoding='utf-8',newline='').write(s)
    print(f,'patched OK, new size', len(s)//1024,'KB')
print('ALL DONE')
