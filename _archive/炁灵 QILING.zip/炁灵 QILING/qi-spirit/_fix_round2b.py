# -*- coding: utf-8 -*-
# 第二轮修复残余：index.html / qiling_10form_standalone.html（按钮带 data-page-node-id，用正则锚点）
import re, os, base64, io
from PIL import Image

KEYS={
 '柔光生命核.png':'softglow','半透明活体膜.png':'membrane','褶皱金属碎箔.png':'metalfoil',
 '柔性哑光金属甲片.png':'matteplate','多孔细胞甲片.png':'cellplate','光纤种子.png':'fiber',
 'particle_softglow_256.png':'dust'}
entries=[]
for f,key in KEYS.items():
    im=Image.open(os.path.join('assets/particle',f)).convert('RGBA')
    if im.size!=(256,256): im=im.resize((256,256), Image.LANCZOS)
    buf=io.BytesIO(); im.save(buf,'PNG',optimize=True)
    entries.append('  %s:"data:image/png;base64,%s"'%(key, base64.b64encode(buf.getvalue()).decode()))
new_data='var PARTICLE_IMG={\n'+',\n'.join(entries)+'\n};'

DENS_BLOCK='''          u.uOpacity.value=_cfg?_cfg.opacity:(skin==='swarm'?0.9:0.5);
          // 密度自适应防过曝：粒子云收缩得越密，透明度越低（害羞内聚/爆发核心不再白化成一团）
          {
            var dT=(mat._dT||0)+1, dR=mat._dR||0;
            if(dT>=10||dR<=0){
              dT=0;
              var dn=0,dsx=0,dsy=0,dsz=0;
              for(var di=0;di<COUNT;di+=30){ dsx+=P[di*3];dsy+=P[di*3+1];dsz+=P[di*3+2];dn++; }
              dsx/=dn;dsy/=dn;dsz/=dn;
              var dacc=0;
              for(var dj=0;dj<COUNT;dj+=30){ var qx=P[dj*3]-dsx,qy=P[dj*3+1]-dsy,qz=P[dj*3+2]-dsz; dacc+=qx*qx+qy*qy+qz*qz; }
              dR=Math.sqrt(dacc/(COUNT/30));
              mat._dR=dR;
            }
            mat._dT=dT;
            var dens=Math.pow(0.52/Math.max(0.10,dR),3);
            u.uOpacity.value*=1/(1+0.45*Math.max(0,dens-1));
          }'''

ST_PARAM='''  // 支持 ?st=状态 直达（分享/调试用，如 ?st=implode 直看害羞态）
  (function(){
    var m=(location.search.match(/[?&]st=([a-z]+)/)||[])[1];
    if(m){ var b=document.querySelector('#stateRow .statebtn[data-state="'+m+'"],#extRow .statebtn[data-state="'+m+'"]'); if(b) b.click(); }
  })();

  // ========== 情绪识别 · 盲测问卷'''

# dust 按钮插入到 softglow 按钮之前（容忍任意属性）
BTN_RE=re.compile(r'(    <button class="particlebtn" data-particle="softglow"[^>]*>)')
DUST_BTN='    <button class="particlebtn" data-particle="dust"><span class="thumb"></span><span class="lbl">柔光尘·通用</span></button>\n\\1'

def rep1(s, old, new, tag, fname):
    n=s.count(old)
    if n!=1: raise SystemExit('%s in %s: %d occurrences'%(tag,fname,n))
    return s.replace(old,new)

for f in ['index.html','qiling_10form_standalone.html']:
    s=open(f,encoding='utf-8').read()
    s,n=re.subn(r'var PARTICLE_IMG=\{[^}]*\};', new_data.replace('\\','\\\\'), s, count=1)
    if n!=1: raise SystemExit('PARTICLE_IMG in '+f)
    s,n=BTN_RE.subn(DUST_BTN, s, count=1)
    if n!=1: raise SystemExit('dust-btn in '+f)
    s=rep1(s,'  var PARTICLE_RENDER={\n','  var PARTICLE_RENDER={\n    dust:      {count:4600, size:0.11, opacity:0.30, additive:1},\n','dust-render',f)
    s=rep1(s,"    return 'softglow';","    return 'dust';",'default-key',f)
    s=rep1(s,'  // ========== 情绪识别 · 盲测问卷',ST_PARAM,'st-param',f)
    s=rep1(s,'          u.uOpacity.value=_cfg?_cfg.opacity:(skin===\'swarm\'?0.9:0.5);',DENS_BLOCK,'density',f)
    open(f,'w',encoding='utf-8',newline='').write(s)
    print(f,'round2 OK,',len(s)//1024,'KB')
print('ROUND2B DONE')
